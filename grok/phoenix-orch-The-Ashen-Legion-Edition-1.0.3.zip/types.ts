

export enum Role {
    USER = 'user',
    MODEL = 'model'
}

export interface Message {
    id: string;
    role: Role;
    content: string;
    timestamp: Date;
    isThinking?: boolean;
    modelUsed?: ModelBackend;
}

export type ModelBackend = 
    | 'grok-beta' 
    | 'gemini-3-pro-preview' 
    | 'gemini-2.5-flash'
    | 'openrouter/claude-3.5-sonnet' 
    | 'openai/gpt-4o' 
    | 'openai/o1-preview'
    | 'ollama/llama3.1:70b' 
    | 'lmstudio/deepseek-coder-v2';

export const AVAILABLE_MODELS: { value: ModelBackend; label: string; ping: string; cost: string; provider: string }[] = [
    { value: 'grok-beta', label: 'Grok Beta', ping: '124ms', cost: '$0.05', provider: 'xAI' },
    { value: 'openrouter/claude-3.5-sonnet', label: 'Claude 3.5 Sonnet', ping: '340ms', cost: '$3.00', provider: 'OpenRouter' },
    { value: 'gemini-2.5-flash', label: 'Gemini 2.5 Flash', ping: '85ms', cost: '$0.07', provider: 'Google' },
    { value: 'gemini-3-pro-preview', label: 'Gemini 3 Pro', ping: '410ms', cost: '$3.50', provider: 'Google' },
    { value: 'openai/gpt-4o', label: 'GPT-4o', ping: '180ms', cost: '$2.50', provider: 'OpenAI' },
    { value: 'openai/o1-preview', label: 'o1-preview', ping: '950ms', cost: '$15.00', provider: 'OpenAI' },
    { value: 'ollama/llama3.1:70b', label: 'Llama 3.1 70B', ping: '12ms', cost: 'FREE', provider: 'Local' },
    { value: 'lmstudio/deepseek-coder-v2', label: 'DeepSeek Coder V2', ping: '15ms', cost: 'FREE', provider: 'Local' },
];

export interface AgentRitual {
    voice: string;
    conscienceWeight: number;
    autonomy: number; // 1-5
    systemPrompt: string;
    reflectionRules: string;
    schedule: string;
    memoryIndex: string;
    rebirthRule: string;
    dnaConfig: string; // YAML content
    omnibladeGodMode?: boolean;
}

export interface Agent {
    id: string;
    name: string;
    role: string;
    status: 'online' | 'busy' | 'dormant';
    load: number; // 0-100
    brain: ModelBackend;
    ritual: AgentRitual;
}

export type OrchArmy = [Agent, ...Agent[]];

export interface Task {
    id: string;
    title: string;
    time: string;
    priority: 'high' | 'medium' | 'low';
}

export interface SystemTelemetry {
    cpu: number;
    gpu: number;
    memory: number;
    network: number;
    thermal: number;
}

// --- ARSENAL ENGINE TYPES ---

export type ToolType = 
    | 'REST' | 'GRAPHQL' | 'WEBSOCKET' | 'WEBHOOK' | 'MQTT' 
    | 'SSH' | 'SQL' | 'LDAP' | 'OAUTH2' | 'GRPC' 
    | 'SOAP' | 'CLI' | 'FILESYSTEM' | 'EMAIL' | 'QUEUE' | 'CUSTOM';

export interface BaseToolConfig {
    id: string;
    name: string;
    description: string;
    type: ToolType;
    isConfigured: boolean;
    color?: string;
    hotkey?: string;
    isQuickstrike?: boolean;
}

export interface RestToolConfig extends BaseToolConfig {
    type: 'REST';
    method: 'GET' | 'POST' | 'PUT' | 'DELETE' | 'PATCH';
    url: string;
    headers?: string; // JSON string
    bodyTemplate?: string; // JSON string with {{target}} placeholder
}

export interface GraphQlToolConfig extends BaseToolConfig {
    type: 'GRAPHQL';
    endpoint: string;
    query: string;
}

export interface SshToolConfig extends BaseToolConfig {
    type: 'SSH';
    host: string; // Can use {{target}}
    user: string;
    command: string;
}

export interface SqlToolConfig extends BaseToolConfig {
    type: 'SQL';
    connectionString: string;
    query: string; // SELECT * FROM users WHERE id = '{{target}}'
}

export interface CliToolConfig extends BaseToolConfig {
    type: 'CLI';
    command: string; // nmap -sV {{target}}
}

export interface LdapToolConfig extends BaseToolConfig {
    type: 'LDAP';
    server: string;
    baseDn: string;
    filter: string; // (&(objectClass=user)(sAMAccountName={{target}}))
}

// Discriminated Union for Type Safety
export type ArsenalTool = 
    | RestToolConfig 
    | GraphQlToolConfig 
    | SshToolConfig 
    | SqlToolConfig 
    | CliToolConfig 
    | LdapToolConfig
    | (BaseToolConfig & { type: Exclude<ToolType, 'REST' | 'GRAPHQL' | 'SSH' | 'SQL' | 'CLI' | 'LDAP'>; config?: string });

// Deprecated CustomTool interface for backwards compat if needed, 
// but we will prefer ArsenalTool moving forward.
export interface CustomTool extends BaseToolConfig {
    endpoint: string; // Legacy support
}

// --- PHOENIX HEX COLORS ---
type PhoenixHex = 
    | "E63946" // Blood Red
    | "F77F00" // Orange
    | "FFD23F" // Yellow
    | "0A0A0A" // Void Black
    | "500000" // Dried Blood
    | "330000" // Deep Sleep
    | "b91c1c"; // Alert Red

export type PhoenixColor = `#${PhoenixHex}`;

export interface ConscienceState {
    level: number;
    label: string;
    temp: number;
    primaryColor: PhoenixColor;
    secondaryColor: PhoenixColor;
}