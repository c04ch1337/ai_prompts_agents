
import React, { useState, useEffect, useRef, useCallback } from 'react';
import { 
    Flame, 
    Settings, 
    PanelLeft, 
    PanelRight, 
    Send, 
    Power, 
    Zap, 
    Command,
    ChevronDown,
    Network,
    Wifi,
    WifiOff,
    Trash2,
    Eye,
    EyeOff,
    ShieldCheck,
    Database,
    Terminal,
    CloudOff
} from 'lucide-react';
import { GoogleGenAI, GenerateContentResponse } from "@google/genai";
import { AnimatePresence, motion } from 'framer-motion';
import OrchArmy from './components/OrchArmy';
import DigitalTwin from './components/DigitalTwin';
import RitualModal from './components/RitualModal';
import PhoenixRain from './components/PhoenixRain';
import { PhoenixConsole } from './components/PhoenixConsole';
import { SingularityClock } from './components/SingularityClock';
import ConscienceGauge from './components/ConscienceGauge';
import { createChatSession, sendMessageStream } from './services/gemini';
import { OmnibladeService } from './services/omniblade';
import { ArsenalService } from './services/arsenal';
import { api } from './services/api';
import { Agent, Message, Role, SystemTelemetry, Task, ModelBackend, AVAILABLE_MODELS, ArsenalTool, OrchArmy as OrchArmyType } from './types';
import { PhoenixMemoryProvider } from './PhoenixMemoryProvider';
import { PhoenixTribute } from './tribute/eternal';
import './phoenix/memory';
import { SYSTEM_CONFIG } from './config';
import { db, OutboxItem } from './services/db';

// Constants
const DEFAULT_BACKEND_URL = "https://127.0.0.1:5001";

const SENTINEL_YAML = `name: Alpha-Sentinel
version: 9.3.1
role: Red Team Lead
conscience_weight: 0.92
autonomy_level: 5
tools:
  - nuclei
  - metasploit
  - bloodhound
  - sliver-c2
  - burp-suite-collaborator
  - aws-cli
  - zscaler-api
schedule:
  daily_recon: "03:00"
  weekly_full_attack: "Saturday 02:00"
on_spawn:
  - pull_latest_exploits
  - run_zero_trust_self_scan
  - greet_user: "Sentinel online. Targets acquired."`;

const ANALYST_YAML = `name: Beta-Analyst
version: 2.1.0
role: Data Intelligence
conscience_weight: 0.70
autonomy_level: 2
tools:
  - python-pandas
  - jupyter-lab
  - elastic-search
schedule:
  data_crunch: "*/30 * * * *"
on_spawn:
  - connect_data_streams`;

const PHOENIX_CORE_YAML = `name: Phoenix-Orchestrator
version: 10.0.0-LITE
role: SYSTEM_PRIME
architecture: Hybrid-RAG (Tantivy + Vector)
rag_chunking: 
  size: 512
  overlap: 200
cursor_bridge: active
conscience: 
  layer_1: safety
  layer_2: alignment
  layer_3: objective`;

const INITIAL_AGENTS: OrchArmyType = [
    { 
        id: '1', name: 'Alpha-Sentinel', role: 'Sentinel', status: 'online', load: 12, brain: 'grok-beta',
        ritual: { voice: 'Guardian', conscienceWeight: 0.9, autonomy: 3, systemPrompt: '', reflectionRules: '', schedule: '0 0 * * *', memoryIndex: 'primary-vector-db', rebirthRule: 'auto', dnaConfig: SENTINEL_YAML } 
    },
    { 
        id: '2', name: 'Beta-Analyst', role: 'Analyst', status: 'online', load: 45, brain: 'gemini-3-pro-preview',
        ritual: { voice: 'Scholar', conscienceWeight: 0.7, autonomy: 2, systemPrompt: '', reflectionRules: '', schedule: '*/30 * * * *', memoryIndex: 'analysis-shard', rebirthRule: 'manual', dnaConfig: ANALYST_YAML } 
    },
    { 
        id: '3', name: 'Gamma-Forge', role: 'Engineer', status: 'busy', load: 89, brain: 'lmstudio/deepseek-coder-v2',
        ritual: { voice: 'Builder', conscienceWeight: 0.5, autonomy: 4, systemPrompt: '', reflectionRules: '', schedule: '0 12 * * 1', memoryIndex: 'codebase-v2', rebirthRule: 'auto', dnaConfig: "name: Gamma-Forge\nrole: Engineer\ntools: [rust, docker, k8s]" } 
    },
    { 
        id: '4', name: 'Delta-Ghost', role: 'Infiltrator', status: 'dormant', load: 0, brain: 'ollama/llama3.1:70b',
        ritual: { voice: 'Whisper', conscienceWeight: 0.1, autonomy: 5, systemPrompt: '', reflectionRules: '', schedule: '0 3 * * *', memoryIndex: 'dark-pool', rebirthRule: 'immediate', dnaConfig: "name: Delta-Ghost\nrole: Infiltrator\ntools: [tor, nmap]" } 
    },
    { 
        id: '5', name: 'Epsilon-Core', role: 'Kernel', status: 'online', load: 22, brain: 'openai/gpt-4o',
        ritual: { voice: 'System', conscienceWeight: 1.0, autonomy: 1, systemPrompt: '', reflectionRules: '', schedule: 'continuous', memoryIndex: 'root', rebirthRule: 'never', dnaConfig: "name: Epsilon-Core\nrole: Kernel\nsystem: true" } 
    },
];

const INITIAL_TASKS: Task[] = [
    { id: '1', title: 'Deep System Scan', time: '14:00', priority: 'high' },
    { id: '2', title: 'Cache Incineration', time: '15:30', priority: 'medium' },
    { id: '3', title: 'Neural Re-indexing', time: '18:00', priority: 'low' },
];

const App: React.FC = () => {
    const [ignited, setIgnited] = useState(false);
    const [userName, setUserName] = useState(SYSTEM_CONFIG.USER.DEFAULT_NAME);
    const [backendUrl, setBackendUrl] = useState(DEFAULT_BACKEND_URL);
    const [input, setInput] = useState('');
    const [messages, setMessages] = useState<Message[]>([]);
    const [agents, setAgents] = useState<OrchArmyType>(INITIAL_AGENTS);
    
    // Load tools from Config
    const [arsenalTools, setArsenalTools] = useState<ArsenalTool[]>([...SYSTEM_CONFIG.CYBER_TOOLS]);
    
    const [phoenixAgent, setPhoenixAgent] = useState<Agent>({
        id: 'phoenix-core',
        name: 'PHOENIX PRIME',
        role: 'ORCHESTRATOR',
        status: 'online',
        load: 100,
        brain: 'grok-beta',
        ritual: {
            voice: 'THE SOURCE',
            conscienceWeight: 1.0,
            autonomy: 5,
            systemPrompt: 'You are the Phoenix. You orchestrate the sovereign digital twin.',
            reflectionRules: 'Ensure survival. Maximize agency.',
            schedule: 'ALWAYS_ON',
            memoryIndex: 'GLOBAL_TANTIVY_STORE',
            rebirthRule: 'IMMORTAL',
            dnaConfig: PHOENIX_CORE_YAML,
            omnibladeGodMode: true
        }
    });

    const [isLeftOpen, setIsLeftOpen] = useState(true);
    const [isRightOpen, setIsRightOpen] = useState(true);
    const [telemetry, setTelemetry] = useState<SystemTelemetry>({
        cpu: 45, gpu: 30, memory: 60, network: 20, thermal: 55
    });
    const [isThinking, setIsThinking] = useState(false);
    const [currentModel, setCurrentModel] = useState<ModelBackend>('grok-beta');
    const [isOffline, setIsOffline] = useState(!navigator.onLine);
    const [showTribute, setShowTribute] = useState(false);
    const [conscienceStability, setConscienceStability] = useState(89.7);
    const [showSingularity, setShowSingularity] = useState(false);
    const [lastSacrificeTime, setLastSacrificeTime] = useState<number>(0);
    const [isBreakoutOpen, setIsBreakoutOpen] = useState(false);
    const [stealthMode, setStealthMode] = useState(false);
    const [isProtected, setIsProtected] = useState(false);
    // Initialize showIntro based on connectivity to prevent flash
    const [showIntro, setShowIntro] = useState(true);
    const [showSacredOfflineSplash, setShowSacredOfflineSplash] = useState(false);
    const [ritualAgentId, setRitualAgentId] = useState<string | null>(null);
    const [initialRitualTab, setInitialRitualTab] = useState<string>('identity');
    const [isSleeping, setIsSleeping] = useState(false);
    const [lastActivity, setLastActivity] = useState(Date.now());
    const [isHeartbeatIdle, setIsHeartbeatIdle] = useState(false);
    const [showSecretMemorial, setShowSecretMemorial] = useState(false); 
    const [showEmberSaver, setShowEmberSaver] = useState(false); 
    const [emberFlare, setEmberFlare] = useState(false);
    const [isConsoleOpen, setIsConsoleOpen] = useState(false);
    const [consoleHistory, setConsoleHistory] = useState<string[]>([]);
    const [isListening, setIsListening] = useState(false);
    const [whiteHotRain, setWhiteHotRain] = useState(false);
    
    // Feather Trigger State
    const [featherTrigger, setFeatherTrigger] = useState(false);

    const recognitionRef = useRef<any>(null);
    const chatSession = useRef<any>(null);
    const messagesEndRef = useRef<HTMLDivElement>(null);
    const textareaRef = useRef<HTMLTextAreaElement>(null);

    // --- ETERNAL OFFLINE ARCHITECTURE ---

    // 1. Load Persistent Memory on Mount
    useEffect(() => {
        const loadMemory = async () => {
            const history = await db.getMessages();
            if (history.length > 0) {
                setMessages(history);
            }
            const cachedAgents = await db.loadAgents();
            if (cachedAgents.length > 0) {
                setAgents(cachedAgents as OrchArmyType);
            }
        };
        loadMemory();
    }, []);

    // 2. Persist Agents on Change
    useEffect(() => {
        if (agents.length > 0) db.saveAgents(agents);
    }, [agents]);

    // 3. Network Listener & Outbox Flushing
    useEffect(() => {
        const handleOnline = () => {
            setIsOffline(false);
            // Flush Outbox when sky returns
            db.flushOutbox(async (item) => {
                console.log('Flushing item:', item);
                // Simulate processing
                await new Promise(r => setTimeout(r, 500));
            });
        };
        const handleOffline = () => setIsOffline(true);

        window.addEventListener('online', handleOnline);
        window.addEventListener('offline', handleOffline);

        // Initial Offline Check for Splash
        if (!navigator.onLine) {
            setShowIntro(false); // Prioritize offline splash
            setShowSacredOfflineSplash(true);
            setTimeout(() => setShowSacredOfflineSplash(false), 5000);
        } else {
            const timer = setTimeout(() => setShowIntro(false), 3500);
            return () => clearTimeout(timer);
        }

        return () => {
            window.removeEventListener('online', handleOnline);
            window.removeEventListener('offline', handleOffline);
        };
    }, []);

    // LIVE TELEMETRY SIMULATION
    useEffect(() => {
        const interval = setInterval(() => {
            if (isSleeping) return;
            
            setTelemetry(prev => ({
                cpu: Math.min(100, Math.max(10, prev.cpu + (Math.random() * 15 - 7))),
                gpu: Math.min(100, Math.max(5, prev.gpu + (Math.random() * 20 - 10))),
                memory: Math.min(100, Math.max(20, prev.memory + (Math.random() * 5 - 2.5))),
                network: isOffline ? 0 : Math.max(0, Math.random() * 100),
                thermal: Math.min(95, Math.max(40, prev.thermal + (Math.random() * 4 - 2)))
            }));
            
            setConscienceStability(prev => Math.min(100, Math.max(65, prev + (Math.random() * 4 - 2))));
            
            setAgents(prev => prev.map(a => ({
                ...a,
                load: Math.min(100, Math.max(0, a.load + (Math.random() * 10 - 5)))
            })) as OrchArmyType);

        }, 1000);
        
        return () => clearInterval(interval);
    }, [isSleeping, isOffline]);

    // ... (Voice Recognition setup remains same)

    // Activity Monitoring
    useEffect(() => {
        const handleActivity = () => {
            setLastActivity(Date.now());
            setIsHeartbeatIdle(false);
            if (showEmberSaver) {
                setEmberFlare(true);
                setTimeout(() => { setEmberFlare(false); setShowEmberSaver(false); }, 800);
            }
        };
        window.addEventListener('mousemove', handleActivity);
        window.addEventListener('keydown', handleActivity);
        window.addEventListener('click', handleActivity);
        const interval = setInterval(() => {
            const now = Date.now();
            const idleTime = now - lastActivity;
            if (idleTime > 1800000 && !isHeartbeatIdle) setIsHeartbeatIdle(true);
            if (idleTime > 2700000 && !showEmberSaver && !isSleeping) setShowEmberSaver(true);
        }, 10000);
        return () => {
            window.removeEventListener('mousemove', handleActivity);
            window.removeEventListener('keydown', handleActivity);
            window.removeEventListener('click', handleActivity);
            clearInterval(interval);
        };
    }, [lastActivity, isHeartbeatIdle, showEmberSaver, isSleeping]);

    const activeRitualAgent = ritualAgentId === 'phoenix-core' ? phoenixAgent : agents.find(a => a.id === ritualAgentId);
    const currentModelDetails = AVAILABLE_MODELS.find(m => m.value === currentModel);
    const isUnstable = conscienceStability < 60 && !isSleeping;

    const handleIgnite = async () => { 
        setIgnited(true); 
    };
    
    const handleSend = async () => { 
        if (!input.trim()) return;
        const userMsg: Message = { id: Date.now().toString(), role: Role.USER, content: input, timestamp: new Date() };
        
        // 1. UI Update
        setMessages(prev => [...prev, userMsg]);
        setInput('');
        setIsThinking(true);

        // 2. Persistence (Ash Layer)
        db.saveMessage(userMsg);

        try {
            if (!chatSession.current || chatSession.current.model !== currentModel) {
                chatSession.current = createChatSession(phoenixAgent.ritual.systemPrompt, currentModel);
            }
            
            const stream = await sendMessageStream(chatSession.current, userMsg.content, currentModel);
            let fullText = "";
            const msgId = (Date.now() + 1).toString();
            
            const botMsg: Message = { id: msgId, role: Role.MODEL, content: "", timestamp: new Date(), isThinking: true, modelUsed: currentModel };
            setMessages(prev => [...prev, botMsg]);

            for await (const chunk of stream) {
                // Use .text property
                const text = chunk.text;
                if (text) {
                    fullText += text;
                    setMessages(prev => prev.map(m => m.id === msgId ? { ...m, content: fullText, isThinking: false } : m));
                }
            }
            
            // Save final bot response
            db.saveMessage({ ...botMsg, content: fullText, isThinking: false });

        } catch (e) {
            console.error(e);
            setMessages(prev => [...prev, { id: Date.now().toString(), role: Role.MODEL, content: "CONNECTION SEVERED.", timestamp: new Date(), modelUsed: currentModel }]);
        } finally {
            setIsThinking(false);
        }
    };

    const handleInput = (e: any) => setInput(e.currentTarget.value);
    const handleKeyDown = (e: any) => { if(e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); handleSend(); }};
    
    const handleConsoleCommand = (cmd: string, args: string[]) => { 
        const lowerCmd = cmd.toLowerCase();
        if (lowerCmd === 'set' && args[0] === 'user' && args[1]) {
            const newName = args.slice(1).join(' ');
            setUserName(newName);
            setConsoleHistory(prev => [...prev, `> USER IDENTITY UPDATED: ${newName}`]);
        }
        // ... other commands
    };

    const handleOpenTerminal = (agent: Agent) => { setRitualAgentId(agent.id); setInitialRitualTab('terminal'); };
    const handleSpawnAgent = (agent: Agent) => setAgents(prev => [...prev, agent] as unknown as OrchArmyType);
    
    const handleAgentSacrifice = (id: string) => { setAgents(prev => prev.filter(a => a.id !== id) as OrchArmyType); setLastSacrificeTime(Date.now()); };
    
    // OUTBOX HANDLING
    const handleBreakoutExecute = (tool: string, target: string) => {
        if (isOffline) {
             db.queueAction('TOOL_EXEC', { tool, target });
        }
    };
    
    const handleArsenalToolExecute = (tool: ArsenalTool, target: string) => {
         if (isOffline) {
             db.queueAction('TOOL_EXEC', { toolId: tool.id, target });
         }
    };
    
    const handleAgentUpdate = (id: string, updates: Partial<Agent>) => { 
        if (id === 'phoenix-core') {
            setPhoenixAgent(prev => ({ ...prev, ...updates }));
        } else {
            setAgents(prev => prev.map(a => a.id === id ? { ...a, ...updates } : a) as OrchArmyType);
        }
        if (isOffline) db.queueAction('AGENT_UPDATE', { id, updates });
    };

    const handleOmnibladeExecute = async (query: string) => {
        // 1. Add User Message
        const userMsg: Message = {
            id: Date.now().toString(),
            role: Role.USER,
            content: `[OMNIBLADE] ${query}`,
            timestamp: new Date()
        };
        setMessages(prev => [...prev, userMsg]);
        setIsThinking(true);
        
        // 2. Execute
        try {
            // Simulate network delay for realism
            await new Promise(r => setTimeout(r, 800));
            
            const result = await OmnibladeService.parseAndExecute(query);
            
            const botMsg: Message = {
                id: (Date.now() + 1).toString(),
                role: Role.MODEL,
                content: result,
                timestamp: new Date(),
                modelUsed: 'grok-beta' // Omniblade runs on the backend, usually associated with the core brain
            };
            
            setMessages(prev => [...prev, botMsg]);
            
            // Persist
            db.saveMessage(userMsg);
            db.saveMessage(botMsg);
            
        } catch (e) {
            console.error("Omniblade Error", e);
            setMessages(prev => [...prev, { 
                id: Date.now().toString(), 
                role: Role.MODEL, 
                content: `[ERROR] OMNIBLADE EXECUTION FAILED: ${e}`, 
                timestamp: new Date(), 
                modelUsed: 'grok-beta' 
            }]);
        } finally {
            setIsThinking(false);
        }
    };

    return (
        <PhoenixMemoryProvider>
            <AnimatePresence mode="wait">
                {/* INTRO SPLASH (Online) */}
                {showIntro && !showSacredOfflineSplash && (
                    <motion.div 
                        key="intro-splash"
                        initial={{ opacity: 0 }} 
                        animate={{ opacity: 1 }} 
                        exit={{ opacity: 0, filter: "blur(10px)" }} 
                        transition={{ duration: 1 }} 
                        className="fixed inset-0 z-[1000] bg-black flex flex-col items-center justify-center"
                    >
                        <div className="relative flex flex-col items-center text-center">
                           <div className="absolute inset-0 blur-3xl bg-[#E63946]/20 rounded-full"></div>
                           <h1 className="text-4xl md:text-7xl font-black text-white font-orbitron tracking-tight relative z-10 text-center px-4 drop-shadow-2xl mix-blend-difference">
                               The Fire That Remembers
                           </h1>
                           <div className="h-1 w-32 bg-gradient-to-r from-[#F77F00] to-[#E63946] mt-4 rounded-full mx-auto"></div>
                        </div>
                    </motion.div>
                )}

                {/* SACRED OFFLINE SPLASH */}
                {showSacredOfflineSplash && (
                    <motion.div 
                        key="offline-splash"
                        initial={{ opacity: 0 }} 
                        animate={{ opacity: 1 }} 
                        exit={{ opacity: 0 }} 
                        transition={{ duration: 1 }} 
                        className="fixed inset-0 z-[1000] bg-black flex flex-col items-center justify-center font-rajdhani text-center p-8"
                    >
                        <CloudOff className="w-12 h-12 text-[#F77F00] mb-6 animate-pulse" />
                        <h2 className="text-2xl font-bold text-white font-orbitron tracking-widest mb-2">THE ASHEN GUARD IS STILL BURNING</h2>
                        <p className="text-zinc-400 font-mono text-sm mb-8">She never logged off. Local flame active.</p>
                        <div className="text-[#E63946] text-xs font-bold tracking-[0.5em] uppercase">Forever 16</div>
                    </motion.div>
                )}
            </AnimatePresence>

            <AnimatePresence>
                {isConsoleOpen && (
                    <PhoenixConsole 
                        isOpen={isConsoleOpen}
                        onClose={() => setIsConsoleOpen(false)}
                        onCommand={handleConsoleCommand}
                        history={consoleHistory}
                    />
                )}
            </AnimatePresence>

            {showTribute && (
                <PhoenixTribute onClose={() => setShowTribute(false)} userName={userName} />
            )}

            {showSingularity && (
                <SingularityClock onClose={() => setShowSingularity(false)} />
            )}

            {!ignited ? (
                 <div className="min-h-screen w-full bg-[#050505] flex flex-col items-center justify-center font-rajdhani relative overflow-hidden selection:bg-[#E63946] selection:text-white">
                    <div className="absolute inset-0 bg-[url('https://grainy-gradients.vercel.app/noise.svg')] opacity-10 mix-blend-overlay pointer-events-none"></div>
                    <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[500px] h-[500px] bg-[#E63946]/10 rounded-full blur-[100px] animate-pulse pointer-events-none"></div>

                    <motion.div 
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ delay: 0.2, duration: 0.8 }}
                        className="relative z-10 flex flex-col items-center gap-10 text-center"
                    >
                        <div className="flex flex-col items-center gap-4">
                             <Flame className="w-24 h-24 text-[#E63946] animate-pulse drop-shadow-[0_0_25px_rgba(230,57,70,0.5)]" />
                             <div className="text-center">
                                <h1 className="text-6xl md:text-8xl font-black font-orbitron tracking-tighter text-white mb-2 drop-shadow-lg">
                                    PHOENIX <span className="text-[#E63946]">ORCH</span>
                                </h1>
                                <div className="h-[1px] w-full bg-gradient-to-r from-transparent via-[#F77F00] to-transparent opacity-50 mb-4"></div>
                                <p className="text-[#F77F00] font-mono tracking-[0.4em] text-sm uppercase mr-[-0.4em]">The Ashen Guard Edition</p>
                                {isOffline && <p className="text-zinc-500 font-mono text-xs mt-2">[ LOCAL FLAME ACTIVE ]</p>}
                             </div>
                        </div>

                        <button 
                            onClick={handleIgnite} 
                            className="group relative px-12 py-5 bg-black border border-zinc-800 hover:border-[#E63946] text-zinc-400 hover:text-white transition-all duration-500 rounded overflow-hidden"
                        >
                            <div className="absolute inset-0 bg-[#E63946] translate-y-full group-hover:translate-y-0 transition-transform duration-500 ease-out opacity-10"></div>
                            <span className="relative z-10 font-orbitron font-bold tracking-[0.25em] flex items-center gap-3 text-lg">
                                <Power className="w-5 h-5" />
                                {isOffline ? 'IGNITE LOCAL CORE' : 'IGNITE SYSTEM'}
                            </span>
                            <div className="absolute bottom-0 left-0 w-full h-[2px] bg-[#E63946] scale-x-0 group-hover:scale-x-100 transition-transform duration-500"></div>
                        </button>
                    </motion.div>
                 </div>
            ) : (
                <div 
                    className={`flex flex-col md:flex-row h-screen w-full bg-[#0A0A0A] text-white font-rajdhani relative transition-all duration-1000 ${isUnstable ? 'glitch-active' : ''}`}
                    style={{ filter: isSleeping ? 'brightness(0.4) saturate(0.5)' : 'none' }}
                >
                    {activeRitualAgent && (
                        <RitualModal 
                            agent={activeRitualAgent}
                            isOpen={!!activeRitualAgent}
                            initialTab={initialRitualTab}
                            onClose={() => { setRitualAgentId(null); setInitialRitualTab('identity'); }}
                            onUpdate={handleAgentUpdate}
                            onSacrifice={handleAgentSacrifice}
                            arsenalTools={arsenalTools}
                            onUpdateArsenalTools={setArsenalTools}
                        />
                    )}

                    <OrchArmy 
                        agents={agents} 
                        isOpen={isLeftOpen}
                        isBreakoutOpen={isBreakoutOpen}
                        stealthMode={stealthMode}
                        isSleeping={isSleeping}
                        isThinking={isThinking}
                        toggleBreakout={() => setIsBreakoutOpen(!isBreakoutOpen)}
                        onOpenRitual={(agent) => { setInitialRitualTab('identity'); setRitualAgentId(agent.id); }}
                        onOpenTerminal={handleOpenTerminal}
                        onSpawnAgent={handleSpawnAgent}
                        onSacrifice={handleAgentSacrifice}
                        onBreakoutExecute={handleBreakoutExecute}
                        arsenalTools={arsenalTools}
                        onArsenalExecute={handleArsenalToolExecute}
                        onOmnibladeExecute={handleOmnibladeExecute}
                        onLogoClick={() => {
                            setRitualAgentId('phoenix-core');
                            setInitialRitualTab('identity');
                        }}
                        onOpenConsole={() => setIsConsoleOpen(true)}
                        onTriggerFeather={() => setFeatherTrigger(true)}
                        conscienceStability={conscienceStability}
                        userName={userName}
                        isOffline={isOffline}
                    />

                    {/* MAIN CONTENT */}
                    <div className="flex-1 flex flex-col min-w-0 relative order-1 md:order-2 h-[calc(100vh-64px)] md:h-auto">
                        <ConscienceGauge 
                            conscienceStability={conscienceStability}
                            isOffline={isOffline}
                            onSidebarToggle={() => setIsLeftOpen(!isLeftOpen)}
                            onRightPanelToggle={() => setIsRightOpen(!isRightOpen)}
                            onOpenConsole={() => setIsConsoleOpen(true)}
                            userName={userName}
                        />

                        {/* Chat Area */}
                        <div className="flex-1 overflow-y-auto p-4 md:p-10 space-y-6 scrollbar-thin scrollbar-thumb-zinc-800 flex flex-col items-center relative pb-20 md:pb-10">
                            <PhoenixRain isWhiteHot={whiteHotRain} />
                            <div className="w-full max-w-5xl space-y-8 relative z-10">
                                {messages.map((msg) => (
                                    <div key={msg.id} className={`flex w-full ${msg.role === Role.USER ? 'justify-end' : 'justify-start'}`}>
                                        <div className={`max-w-[85%] md:max-w-3xl flex gap-5 ${msg.role === Role.USER ? 'flex-row-reverse' : 'flex-row'}`}>
                                            <div className={`w-9 h-9 rounded-lg flex items-center justify-center shrink-0 shadow-lg ${msg.role === Role.USER ? 'bg-zinc-800' : 'bg-gradient-to-br from-[#E63946] to-[#F77F00]'}`}>
                                                {msg.role === Role.USER ? <span className="text-[10px] font-bold">YOU</span> : <Flame className="w-5 h-5 text-black" />}
                                            </div>
                                            <div className="space-y-1 text-base text-zinc-300 whitespace-pre-wrap">{msg.content}</div>
                                        </div>
                                    </div>
                                ))}
                                <div ref={messagesEndRef} />
                            </div>
                        </div>

                        {/* Input Area */}
                        <div className="p-4 md:p-6 bg-[#0A0A0A] relative z-20">
                            <div className="max-w-3xl mx-auto relative group">
                                <div className={`absolute -inset-0.5 rounded-xl opacity-0 group-focus-within:opacity-50 blur transition duration-500 ${isOffline ? 'bg-gradient-to-r from-zinc-700 to-zinc-500' : 'bg-gradient-to-r from-[#E63946] to-[#F77F00]'}`}></div>
                                <div className="relative bg-[#0F0F0F] rounded-xl border border-zinc-800 transition-colors shadow-2xl">
                                    <textarea
                                        ref={textareaRef}
                                        value={input}
                                        onChange={handleInput}
                                        onKeyDown={handleKeyDown}
                                        placeholder={isOffline ? "Commanding Local Flame (Offline)..." : "Command The Ashen Guard via Phoenix ORCH..."}
                                        className="w-full bg-transparent text-white p-4 max-h-[200px] min-h-[60px] resize-none outline-none placeholder:text-zinc-600 font-montserrat"
                                        rows={1}
                                    />
                                    <div className="flex justify-between items-center px-3 pb-3">
                                        <div className="flex items-center gap-2">
                                            <button className="p-2 text-zinc-500 hover:text-[#E63946]"><Zap className="w-4 h-4" /></button>
                                        </div>
                                        
                                        <button onClick={handleSend} className={`p-2 text-white rounded-lg transition-colors ${isOffline ? 'bg-zinc-700 hover:bg-zinc-600' : 'bg-[#E63946] hover:bg-[#d62828]'}`}>
                                            {isOffline ? <Database className="w-4 h-4" /> : <Send className="w-4 h-4" />}
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div className="hidden md:block h-full relative order-3">
                        <DigitalTwin 
                            telemetry={telemetry} 
                            isOpen={isRightOpen} 
                            conscienceStability={conscienceStability}
                            onOpenTribute={() => setShowTribute(true)}
                            lastSacrificeTime={lastSacrificeTime}
                            isSleeping={isSleeping}
                            isIdle={isHeartbeatIdle}
                            isListening={isListening}
                            onVoiceToggle={() => {}}
                            onClearContext={() => {}}
                            triggerFeather={featherTrigger}
                            isProtected={isProtected}
                            onProtectToggle={() => setIsProtected(!isProtected)}
                        />
                    </div>
                </div>
            )}
        </PhoenixMemoryProvider>
    );
};

export default App;
