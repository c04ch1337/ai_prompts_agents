
// CONFIGURATION & ENVIRONMENT VARIABLES
// This acts as the .env.local equivalent for the Frontend Interface.

import { ArsenalTool } from './types';

export const SYSTEM_CONFIG = {
    // SYSTEM IDENTITY
    IDENTITY: {
        NAME: "Phoenix ORCH Lite",
        VERSION: "1.0.5-ASHEN_GUARD",
        BUILD: "2024.10.25"
    },

    // USER SETTINGS (Mutable)
    USER: {
        DEFAULT_NAME: "Dad", // The default name the system calls the user
        FALLBACK_NAME: "Operator"
    },

    // API ENDPOINTS & INTEGRATIONS
    API: {
        GEMINI: {
            url: "https://generativelanguage.googleapis.com/v1beta/models",
            desc: "Primary Cognitive Engine (Google Gemini). Handles reasoning, creative generation, and chat."
        },
        OLLAMA: {
            url: "http://localhost:11434/api/generate",
            desc: "Local LLM Inference Engine. Used when 'Offline Mode' is active or for stealth operations."
        },
        VECTOR_STORE: {
            url: "http://localhost:6333",
            desc: "Qdrant Vector Database. Stores long-term semantic memories (RAG)."
        },
        STABLE_DIFFUSION: {
            url: "http://127.0.0.1:7860",
            desc: "Local Image Generation (Automatic1111). Visual imagination engine."
        },
        GITHUB: {
            url: "https://api.github.com",
            desc: "Version Control Sync. Used by Project Blade."
        }
    },

    // LINKS & RESOURCES
    LINKS: {
        GITHUB_REPO: "https://github.com/phoenix-legacy/core",
        DOCS: "https://phoenix.internal/docs",
        BILLING: "https://ai.google.dev/pricing"
    },

    // CYBER BLADE DEFAULT TOOLS
    CYBER_TOOLS: [
        {
            id: 'qs-nmap',
            name: 'Nmap Fast',
            description: 'Standard Port Scan',
            type: 'CLI',
            isConfigured: true,
            command: 'nmap -F {{target}}',
            isQuickstrike: true
        },
        {
            id: 'qs-nuclei',
            name: 'Nuclei Public',
            description: 'Vulnerability Scanner',
            type: 'CLI',
            isConfigured: true,
            command: 'nuclei -u {{target}}',
            isQuickstrike: true
        },
        {
            id: 'qs-whois',
            name: 'WHOIS + DNS',
            description: 'Domain Info',
            type: 'CLI',
            isConfigured: true,
            command: 'dig +whois {{target}}',
            isQuickstrike: true
        },
        {
            id: 'qs-ssh-check',
            name: 'SSH Audit',
            description: 'Check SSH Protocol',
            type: 'SSH',
            isConfigured: true,
            host: '{{target}}',
            user: 'root',
            command: 'cat /etc/os-release',
            isQuickstrike: false
        }
    ] as ArsenalTool[]
};
