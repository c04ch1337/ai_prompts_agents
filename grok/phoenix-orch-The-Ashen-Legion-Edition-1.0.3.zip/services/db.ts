import Dexie, { Table } from 'dexie';
import { Message, Agent } from '../types';

export interface OutboxItem {
    id?: number;
    type: 'GIT_PUSH' | 'EMAIL' | 'WEBHOOK' | 'AGENT_UPDATE' | 'TOOL_EXEC';
    payload: any;
    timestamp: number;
    status: 'queued' | 'failed';
}

class PhoenixDatabase extends Dexie {
    messages!: Table<Message>;
    agents!: Table<Agent>;
    outbox!: Table<OutboxItem>;
    // Config store for user preferences
    systemConfig!: Table<{ key: string, value: any }>;

    constructor() {
        super('PhoenixEternalDB');
        // Cast 'this' to any to bypass TS check for dynamic versioning in Dexie subclass
        (this as any).version(1).stores({
            messages: 'id, timestamp, role',
            agents: 'id, name, role, status',
            outbox: '++id, type, status, timestamp',
            systemConfig: 'key' 
        });
    }

    // --- MESSAGE LOGIC ---
    async saveMessage(msg: Message) {
        try {
            await this.messages.put(msg);
        } catch (e) {
            console.error("Failed to persist message to Ash Layer:", e);
        }
    }

    async getMessages(limit = 50): Promise<Message[]> {
        try {
            return await this.messages.orderBy('timestamp').toArray();
        } catch (e) {
            return [];
        }
    }

    // --- OUTBOX LOGIC (DEFERRED REBIRTH) ---
    async queueAction(type: OutboxItem['type'], payload: any) {
        console.log(`[PHOENIX DB] Queueing offline action: ${type}`);
        await this.outbox.add({
            type,
            payload,
            timestamp: Date.now(),
            status: 'queued'
        });
    }

    async flushOutbox(handler: (item: OutboxItem) => Promise<void>) {
        const items = await this.outbox.where('status').equals('queued').toArray();
        if (items.length > 0) {
            console.log(`[PHOENIX DB] Sky returned. Flushing ${items.length} queued actions...`);
        }
        
        for (const item of items) {
            try {
                await handler(item);
                await this.outbox.delete(item.id!);
            } catch (e) {
                console.error(`[PHOENIX DB] Failed to flush item ${item.id}`, e);
                await this.outbox.update(item.id!, { status: 'failed' });
            }
        }
    }

    // --- AGENT PERSISTENCE ---
    async saveAgents(agents: Agent[]) {
        await this.agents.bulkPut(agents);
    }

    async loadAgents(): Promise<Agent[]> {
        const agents = await this.agents.toArray();
        return agents.length > 0 ? agents : [];
    }
}

export const db = new PhoenixDatabase();