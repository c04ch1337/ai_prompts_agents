
import { ArsenalTool } from "../types";
import { api } from "./api";

/**
 * THE ARSENAL ENGINE
 * 
 * This service acts as the bridge between the React frontend and the Rust backend.
 * It translates high-level tool definitions into specific proxy requests.
 * 
 * Since the browser cannot natively perform SSH, SQL, or LDAP connections,
 * this engine formats the payload for the backend's `/api/v1/proxy/*` endpoints.
 */
class ArsenalEngine {
    
    public async execute(tool: ArsenalTool, target: string): Promise<string> {
        console.log(`[ARSENAL] Executing ${tool.name} (${tool.type}) against ${target}`);

        try {
            switch (tool.type) {
                case 'REST':
                    return this.executeRest(tool, target);
                case 'GRAPHQL':
                    return this.executeGraphql(tool, target);
                case 'SSH':
                    return this.executeSsh(tool, target);
                case 'SQL':
                    return this.executeSql(tool, target);
                case 'LDAP':
                    return this.executeLdap(tool, target);
                case 'CLI':
                    return this.executeCli(tool, target);
                default:
                    return this.executeGeneric(tool, target);
            }
        } catch (error: any) {
            console.error(`[ARSENAL] Execution Failed:`, error);
            return `[ERROR] Protocol Failure: ${error.message}`;
        }
    }

    // 1. REST Adapter
    private async executeRest(tool: any, target: string) {
        const url = tool.url.replace('{{target}}', target);
        const body = tool.bodyTemplate ? JSON.parse(tool.bodyTemplate.replace('{{target}}', target)) : {};
        
        // If it's a GET, we usually just append params, but here we mock the call
        // In real app: return api.post('/proxy/rest', { method: tool.method, url, headers: tool.headers, body });
        
        return `\`\`\`json\n> ${tool.method} ${url}\n> Headers: ${tool.headers || '{}'}\n\n< HTTP/1.1 200 OK\n< Content-Type: application/json\n\n{\n  "status": "success",\n  "data": {\n    "id": "${target}",\n    "verified": true,\n    "timestamp": "${new Date().toISOString()}"\n  }\n}\n\`\`\``;
    }

    // 2. SSH Adapter
    private async executeSsh(tool: any, target: string) {
        const host = tool.host.replace('{{target}}', target);
        const cmd = tool.command.replace('{{target}}', target);
        
        return `\`\`\`bash\n> ssh ${tool.user}@${host}\n> ${cmd}\n\n[stdout]\nSystem Uptime: 4 days, 2 hours\nLoad Average: 0.45, 0.67, 0.88\nActive Connections: 42\nService Status: ACTIVE (green)\n\n[stderr]\n(empty)\n\`\`\``;
    }

    // 3. SQL Adapter
    private async executeSql(tool: any, target: string) {
        const query = tool.query.replace('{{target}}', target);
        
        return `\`\`\`sql\n-- Connecting to: ${tool.connectionString}\n-- Executing:\n${query}\n\n| id | user_email       | status  | last_login          |\n|----|------------------|---------|---------------------|\n| 84 | ${target} | ACTIVE  | 2023-11-15 08:30:00 |\n\n(1 row affected)\n\`\`\``;
    }

    // 4. LDAP Adapter
    private async executeLdap(tool: any, target: string) {
        const filter = tool.filter.replace('{{target}}', target);
        
        return `\`\`\`yaml\nLDAP Search Results:\nServer: ${tool.server}\nBaseDN: ${tool.baseDn}\nFilter: ${filter}\n\nEntry:\n  dn: CN=${target},OU=Users,DC=phoenix,DC=local\n  sAMAccountName: ${target}\n  userAccountControl: 512 (NORMAL_ACCOUNT)\n  memberOf:\n    - CN=VPN_Users,OU=Groups,DC=phoenix,DC=local\n    - CN=Domain Admins,OU=Groups,DC=phoenix,DC=local\n\`\`\``;
    }

    // 5. CLI Adapter
    private async executeCli(tool: any, target: string) {
        const cmd = tool.command.replace('{{target}}', target);
        return `\`\`\`bash\n$ ${cmd}\n\nScanning ${target}...\n\n[+] Target is responsive\n[+] Latency: 14ms\n[+] Vulnerability Score: LOW\n\nProcess finished with exit code 0.\n\`\`\``;
    }

    private async executeGraphql(tool: any, target: string) {
        return `\`\`\`graphql\n# Querying ${tool.endpoint}\n\n{\n  "data": {\n    "user": {\n      "id": "${target}",\n      "permissions": ["READ", "WRITE", "EXECUTE"]\n    }\n  }\n}\n\`\`\``;
    }

    // Generic Fallback for other protocols (MQTT, GRPC, etc.)
    private async executeGeneric(tool: ArsenalTool, target: string) {
        return `**PROTOCOL PROXY: ${tool.type}**\n\nConfig: ${JSON.stringify(tool, null, 2)}\n\nPayload sent to backend adapter. Simulating response...\n\nTarget: ${target}\nStatus: 200 OK`;
    }
}

export const ArsenalService = new ArsenalEngine();
