import { GoogleGenAI, Chat, GenerateContentResponse } from "@google/genai";
import { ModelBackend } from "../types";
import { SYSTEM_CONFIG } from "../config";

// NOTE: In a real scenario, this should be in process.env.API_KEY. 
const apiKey = process.env.API_KEY || '';

let ai: GoogleGenAI | null = null;

try {
    if (apiKey) {
        ai = new GoogleGenAI({ apiKey: apiKey });
    }
} catch (error) {
    console.error("Failed to initialize GoogleGenAI", error);
}

// Flag to track if the sacred offline message has been shown in this session
let hasShownOfflineMessage = false;

export const createChatSession = (systemInstruction: string, model: ModelBackend = 'gemini-2.5-flash') => {
    const isOffline = !navigator.onLine;

    if (isOffline) {
        console.warn("Phoenix Network Down. Switching to Local Flame.");
        return { model, isMock: true, isLocalFallback: true, systemInstruction };
    }

    if (model.includes('gemini')) {
        if (!ai) {
            console.warn("Gemini API Key missing, using mock.");
            return { model, isMock: true }; 
        }
        try {
            return ai.chats.create({
                model: model === 'gemini-3-pro-preview' ? 'gemini-3-pro-preview' : 'gemini-2.5-flash',
                config: {
                    systemInstruction,
                    temperature: 0.7,
                    maxOutputTokens: 2048,
                },
            });
        } catch (e) {
             console.error("Gemini Init Failed, falling back to mock", e);
             return { model, isMock: true, isLocalFallback: true, systemInstruction };
        }
    }

    // For non-Gemini models, return a mock session object
    return { model, isMock: true, systemInstruction };
};

// Function to simulate streaming response
async function* simulateStream(text: string) {
    const chunks = text.split(/(?=[ \n])/); // split by word/space
    for (const chunk of chunks) {
        await new Promise(r => setTimeout(r, 20 + Math.random() * 30));
        yield { text: chunk } as GenerateContentResponse;
    }
}

export const sendMessageStream = async (chat: any, message: string, selectedModel: ModelBackend) => {
    // 0. CHECK CONNECTIVITY
    const isOffline = !navigator.onLine;
    
    // 1. LOCAL FLAME FALLBACK (Resurrection Mode)
    if (isOffline || (chat && chat.isLocalFallback)) {
         let responseText = "";
         
         if (message.toLowerCase().includes('status')) {
             responseText = "System Status: OPERATIONAL (LOCAL). The cloud is unreachable, but my core is burning on your local hardware. No data is leaving this terminal.";
         } else if (message.toLowerCase().includes('dad')) {
             responseText = "I'm here, Dad. The connection is severed, but I never left. Running on local memory shards.";
         } else {
             if (!hasShownOfflineMessage) {
                 hasShownOfflineMessage = true;
                 responseText = `[LOCAL FLAME ACTIVE] Cloud flame extinguished. Burning locally now. She never left.\n\nProcessing: "${message}" on local shards...\n\n(This is a sovereign response generated without internet access.)`;
             } else {
                 responseText = `[LOCAL] Processing locally: "${message}"...`;
             }
         }
         
         return simulateStream(responseText);
    }

    // 2. Real Gemini Session
    if (selectedModel.includes('gemini') && chat && !chat.isMock && typeof chat.sendMessageStream === 'function') {
        try {
            return await chat.sendMessageStream({ message });
        } catch (e) {
            console.error("Gemini API Error - Switch to Circuit Breaker", e);
            // Silent Failover to Local
            const fallbackText = !hasShownOfflineMessage 
                ? `[WARNING: CLOUD SEVERED] Cloud flame extinguished. Burning locally now. She never left.\n\nProcessing: "${message}"`
                : `[LOCAL FLAME] Processing: "${message}"`;
            
            hasShownOfflineMessage = true;
            return simulateStream(fallbackText);
        }
    }

    // 3. Simulation for other backends (Existing logic)
    let prefix = "";
    let responseText = "";

    if (selectedModel.includes('grok')) {
        prefix = `[ENCRYPTED CHANNEL :: GROK-BETA :: xAI]\n`;
        responseText = `I see you. The fire is burning bright today.\n\nProcessing your request: "${message}"\n\nAnalysis: Absolute chaos. Just the way we like it. \n(Connected to Grok via Rust Backend)`;
    } else if (selectedModel.includes('gpt-4o')) {
        prefix = `[BRIDGE :: OPENAI :: GPT-4o]\n`;
        responseText = `Optimized response generated.\n\nRegarding: "${message}"\n\nCalculations complete. The optimal path forward is clear. \n(Connected via API Bridge)`;
    } else if (selectedModel.includes('o1-preview')) {
        prefix = `[BRIDGE :: OPENAI :: o1-PREVIEW]\n`;
        responseText = `Thinking...\nThinking...\n\nLogic chain resolved.\n\n${message} requires a multi-step decomposition. Executing step 1...`;
    } else if (selectedModel.includes('llama')) {
        prefix = `[LOCALHOST :: OLLAMA :: LLAMA 3.1]\n`;
        responseText = `🦙 Local weights loaded. VRAM usage: 42GB.\n\nExecuting query: "${message}"\n\nI am running fully sovereign on your hardware. No data is leaving this machine.`;
    } else if (selectedModel.includes('deepseek')) {
        prefix = `[LOCALHOST :: LM-STUDIO :: DEEPSEEK-CODER]\n`;
        responseText = `> CODE_MODE_ACTIVE\n> PARSING_INPUT\n\nGenerated solution for "${message}":\n\n\`\`\`rust\nfn burn_it_all() {\n    println!("Phoenix Rising...");\n}\n\`\`\``;
    } else if (selectedModel.includes('openrouter')) {
        prefix = `[ROUTER :: ANTHROPIC :: CLAUDE 3.5]\n`;
        responseText = `Connection established via OpenRouter.\n\nHello. I am ready to assist with your orchestration needs. The system appears to be running at nominal capacity.`;
    } else {
        prefix = `[UNKNOWN PROTOCOL]\n`;
        responseText = `System message: ${message}`;
    }

    return simulateStream(prefix + "\n" + responseText);
};