
export class ApiService {
    private static instance: ApiService;
    private baseUrl: string = "https://127.0.0.1:5001";
    private tokenKey: string = "phoenix_auth_token";

    private constructor() {}

    public static getInstance(): ApiService {
        if (!ApiService.instance) {
            ApiService.instance = new ApiService();
        }
        return ApiService.instance;
    }

    public setBaseUrl(url: string) {
        // Remove trailing slash to ensure consistency
        this.baseUrl = url.replace(/\/$/, "");
    }

    public getBaseUrl(): string {
        return this.baseUrl;
    }

    public setToken(token: string) {
        localStorage.setItem(this.tokenKey, token);
    }

    public getToken(): string | null {
        return localStorage.getItem(this.tokenKey);
    }

    public clearToken() {
        localStorage.removeItem(this.tokenKey);
    }

    /**
     * Generic request method with Auth Interceptor
     */
    private async request<T>(endpoint: string, options: RequestInit = {}): Promise<T> {
        const token = this.getToken();
        
        const headers: HeadersInit = {
            'Content-Type': 'application/json',
            ...(options.headers || {}),
        };

        // INTERCEPTOR: Attach Bearer Token if available
        if (token) {
            (headers as any)['Authorization'] = `Bearer ${token}`;
        }

        const config: RequestInit = {
            ...options,
            headers,
        };

        // Construct full URL
        const url = `${this.baseUrl}${endpoint.startsWith('/') ? endpoint : '/' + endpoint}`;

        try {
            const response = await fetch(url, config);

            // INTERCEPTOR: Handle 401 Unauthorized
            if (response.status === 401) {
                console.warn('[Phoenix API] 401 Unauthorized - Token invalid or expired.');
                // In a full auth flow, you would trigger a logout or refresh here
                throw new Error('Unauthorized');
            }

            if (!response.ok) {
                const errorText = await response.text();
                throw new Error(`API Error ${response.status}: ${errorText || response.statusText}`);
            }

            // Handle 204 No Content
            if (response.status === 204) {
                return {} as T;
            }

            // Parse JSON safely, fallback to text
            try {
                return await response.json() as T;
            } catch (e) {
                const text = await response.text();
                return text as unknown as T;
            }

        } catch (error) {
            console.error(`[Phoenix API] Fetch failed for ${url}`, error);
            throw error;
        }
    }

    // Public HTTP Methods

    public get<T>(endpoint: string) {
        return this.request<T>(endpoint, { method: 'GET' });
    }

    public post<T>(endpoint: string, body: any) {
        return this.request<T>(endpoint, {
            method: 'POST',
            body: JSON.stringify(body)
        });
    }

    public put<T>(endpoint: string, body: any) {
        return this.request<T>(endpoint, {
            method: 'PUT',
            body: JSON.stringify(body)
        });
    }

    public delete<T>(endpoint: string) {
        return this.request<T>(endpoint, { method: 'DELETE' });
    }
}

export const api = ApiService.getInstance();
