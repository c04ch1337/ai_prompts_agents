
import React, { useState, useEffect } from 'react';
import { 
    X, 
    Fingerprint, 
    Brain, 
    Wrench, 
    MessageSquare, 
    Calendar, 
    HardDrive, 
    RefreshCw,
    Flame,
    Lock,
    Triangle,
    Skull,
    Scan,
    Wifi,
    FileCode,
    UploadCloud,
    FileText,
    Plus,
    Server,
    Code2,
    Heart,
    Hammer,
    Link,
    Edit2,
    Check,
    Sparkles,
    ChevronDown,
    Terminal,
    Trash2,
    Zap
} from 'lucide-react';
import { Agent, AVAILABLE_MODELS, ArsenalTool, ToolType } from '../types';

interface RitualModalProps {
    agent: Agent;
    isOpen: boolean;
    initialTab?: string;
    onClose: () => void;
    onUpdate: (id: string, updates: Partial<Agent>) => void;
    onSacrifice: (id: string) => void;
    onOpenTribute?: () => void;
    arsenalTools?: ArsenalTool[];
    onUpdateArsenalTools?: (tools: ArsenalTool[]) => void;
}

const TABS = [
    { id: 'identity', label: 'IDENTITY', icon: Fingerprint, sacred: false },
    { id: 'autonomy', label: 'AUTONOMY', icon: Triangle, sacred: false },
    { id: 'brain', label: 'BRAIN', icon: Brain, sacred: false },
    { id: 'tools', label: 'TOOLS', icon: Wrench, sacred: false },
    { id: 'prompts', label: 'PROMPTS', icon: MessageSquare, sacred: false },
    { id: 'terminal', label: 'TERMINAL', icon: Terminal, sacred: false },
    { id: 'schedule', label: 'SCHEDULE', icon: Calendar, sacred: true },
    { id: 'memory', label: 'MEMORY', icon: HardDrive, sacred: true },
    { id: 'arsenal', label: 'ARSENAL FORGE', icon: Hammer, sacred: true },
    { id: 'rebirth', label: 'REBIRTH', icon: RefreshCw, sacred: true },
];

const TOOL_TYPES: ToolType[] = [
    'REST', 'SSH', 'SQL', 'GRAPHQL', 'LDAP', 'WEBHOOK', 'CLI', 'MQTT', 'GRPC', 'EMAIL'
];

const PhoenixFeatherToggle = ({ locked, onToggle }: { locked: boolean; onToggle: () => void }) => {
    return (
        <button 
            onClick={onToggle}
            className="relative w-9 h-9 flex items-center justify-center group outline-none cursor-pointer"
            title={locked ? "Protocol Locked (Safe)" : "Protocol Unlocked (GOD MODE)"}
        >
            {/* Ambient Glow */}
            <div className={`absolute inset-0 rounded-full blur-md transition-all duration-500 ${
                locked ? 'bg-[#E63946]/30 opacity-100 scale-110' : 'bg-orange-500/0 opacity-0 scale-100'
            }`} />

            <svg viewBox="0 0 24 24" className="w-full h-full overflow-visible transition-all duration-700">
                <defs>
                    <linearGradient id="featherGradient" x1="0%" y1="0%" x2="0%" y2="100%">
                        <stop offset="0%" stopColor="#E63946" />
                        <stop offset="100%" stopColor="#F77F00" />
                    </linearGradient>
                </defs>

                {/* The Quill/Spine */}
                <path 
                    d="M12 2 C12 2 12 12 12 22" 
                    stroke={locked ? "#FFD23F" : "#444"} 
                    strokeWidth={locked ? "1.5" : "1"}
                    strokeLinecap="round"
                    className="transition-colors duration-500"
                />

                {/* Left Vane */}
                <path 
                    d={locked 
                        ? "M12 2 Q 6 8 6 14 Q 9 18 12 22" // Closed
                        : "M12 2 Q 2 6 5 12 Q 1 16 4 19 Q 8 21 12 22" // Splayed
                    }
                    fill={locked ? "url(#featherGradient)" : "#18181b"}
                    stroke={locked ? "none" : "#444"}
                    strokeWidth="0.5"
                    className="transition-all duration-700 ease-in-out"
                    style={{ filter: locked ? 'drop-shadow(0 0 2px rgba(230, 57, 70, 0.5))' : 'none' }}
                />

                {/* Right Vane */}
                <path 
                    d={locked 
                        ? "M12 2 Q 18 8 18 14 Q 15 18 12 22" 
                        : "M12 2 Q 22 6 19 12 Q 23 16 20 19 Q 16 21 12 22"
                    }
                    fill={locked ? "url(#featherGradient)" : "#18181b"}
                    stroke={locked ? "none" : "#444"}
                    strokeWidth="0.5"
                    className="transition-all duration-700 ease-in-out"
                    style={{ filter: locked ? 'drop-shadow(0 0 2px rgba(230, 57, 70, 0.5))' : 'none' }}
                />
                
                {/* Center Core (Only when unlocked) */}
                <circle 
                    cx="12" 
                    cy="12" 
                    r={locked ? "0" : "1.5"} 
                    fill="#F77F00" 
                    className="transition-all duration-500"
                    style={{ opacity: locked ? 0 : 0.8 }}
                />
            </svg>
        </button>
    );
};

const RitualModal: React.FC<RitualModalProps> = ({ 
    agent, 
    isOpen, 
    initialTab = 'identity',
    onClose, 
    onUpdate, 
    onSacrifice, 
    onOpenTribute,
    arsenalTools = [],
    onUpdateArsenalTools
}) => {
    const [activeTab, setActiveTab] = useState(initialTab);
    const [unlocked, setUnlocked] = useState(false);
    const [unlocking, setUnlocking] = useState(false);
    
    // Arsenal Editing State
    const [editingToolId, setEditingToolId] = useState<string | null>(null);
    const [editForm, setEditForm] = useState<Partial<ArsenalTool>>({});
    const [mockLogs, setMockLogs] = useState<string[]>([]);

    const isCore = agent.id === 'phoenix-core';

    useEffect(() => {
        setUnlocked(false);
        setUnlocking(false);
        setActiveTab(initialTab);
        setMockLogs([
            `[${new Date().toLocaleTimeString()}] INIT_SEQUENCE_START`,
            `[${new Date().toLocaleTimeString()}] LOADING_WEIGHTS: ${agent.brain}`,
            `[${new Date().toLocaleTimeString()}] CONNECTED_TO_ORCHESTRATOR`,
        ]);
    }, [agent.id, isOpen, initialTab]);

    // Live log simulation
    useEffect(() => {
        if (activeTab !== 'terminal') return;
        const interval = setInterval(() => {
            const newLog = `[${new Date().toLocaleTimeString()}] ${['THOUGHT_STREAM_UPDATE', 'VECTOR_INDEXING', 'PING_LATENCY_CHECK', 'MEMORY_SHARD_SYNC', 'HEARTBEAT'][Math.floor(Math.random() * 5)]}: OK`;
            setMockLogs(prev => [...prev.slice(-15), newLog]);
        }, 2000);
        return () => clearInterval(interval);
    }, [activeTab]);

    if (!isOpen) return null;

    const handleUpdate = (updates: Partial<Agent> | any) => {
        onUpdate(agent.id, updates);
    };

    const handleUnlock = () => {
        setUnlocking(true);
        setTimeout(() => {
            setUnlocked(true);
            setUnlocking(false);
        }, 1500);
    };

    const handleSaveTool = () => {
        if (!onUpdateArsenalTools || !editingToolId) return;
        
        const updatedTools = arsenalTools.map(t => 
            t.id === editingToolId ? { ...t, ...editForm, isConfigured: true } as ArsenalTool : t
        );
        onUpdateArsenalTools(updatedTools);
        setEditingToolId(null);
        setEditForm({});
    };

    const handleCreateTool = () => {
        if (!onUpdateArsenalTools) return;
        const newTool: ArsenalTool = {
            id: `tool-${Date.now()}`,
            name: 'New Protocol',
            description: 'Configure connection details',
            type: 'REST',
            isConfigured: false,
            method: 'GET',
            url: 'https://api.target.com/{{target}}'
        } as ArsenalTool;
        
        onUpdateArsenalTools([...arsenalTools, newTool]);
        setEditingToolId(newTool.id);
        setEditForm(newTool);
    };

    const handleDeleteTool = (id: string) => {
        if (!onUpdateArsenalTools) return;
        onUpdateArsenalTools(arsenalTools.filter(t => t.id !== id));
        if (editingToolId === id) {
            setEditingToolId(null);
            setEditForm({});
        }
    };

    return (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/95 backdrop-blur-md animate-in fade-in duration-200">
            <div className={`w-full max-w-5xl h-[85vh] bg-[#0A0A0A] border flex flex-col relative overflow-hidden rounded-lg font-rajdhani transition-colors ${isCore ? 'border-[#F77F00] shadow-[0_0_100px_rgba(247,127,0,0.2)]' : 'border-[#E63946] shadow-[0_0_100px_rgba(230,57,70,0.3)]'}`}>
                
                <div className="absolute inset-0 pointer-events-none overflow-hidden">
                    <div className={`absolute top-0 left-0 w-64 h-64 opacity-5 blur-[120px] rounded-full translate-x-[-50%] translate-y-[-50%] ${isCore ? 'bg-[#FFD23F]' : 'bg-[#E63946]'}`}></div>
                    <div className={`absolute bottom-0 right-0 w-64 h-64 opacity-5 blur-[120px] rounded-full translate-x-[50%] translate-y-[50%] ${isCore ? 'bg-[#F77F00]' : 'bg-[#F77F00]'}`}></div>
                    <div className="absolute inset-0 bg-[url('https://grainy-gradients.vercel.app/noise.svg')] opacity-5"></div>
                </div>

                <div className="flex items-center justify-between p-6 border-b border-zinc-800 bg-black/80 z-10 relative">
                    <div className={`absolute bottom-0 left-0 h-[1px] bg-gradient-to-r w-1/2 ${isCore ? 'from-[#F77F00] to-transparent' : 'from-[#E63946] to-transparent'}`}></div>
                    <div className="flex items-center gap-5">
                        <div className="relative">
                            <div className={`absolute inset-0 blur opacity-40 animate-pulse ${isCore ? 'bg-[#F77F00]' : 'bg-[#E63946]'}`}></div>
                            <div className={`p-2 bg-black border relative z-10 ${isCore ? 'border-[#F77F00]' : 'border-[#E63946]'}`}>
                                <Flame className={`w-6 h-6 ${isCore ? 'text-[#F77F00]' : 'text-[#E63946]'}`} />
                            </div>
                        </div>
                        <div>
                            <h2 className="text-2xl font-bold tracking-tighter text-white flex items-center gap-3 font-orbitron">
                                {isCore ? 'PHOENIX PRIME SETTINGS' : `RITUAL OF ${agent.name.toUpperCase()}`}
                            </h2>
                            <div className="flex items-center gap-3 text-[10px] font-mono tracking-widest mt-1">
                                <span className={isCore ? 'text-[#F77F00]' : 'text-[#E63946]'}>ID: {agent.id}</span>
                                <span className="text-zinc-600">|</span>
                                <span className="text-zinc-400">{agent.role.toUpperCase()}</span>
                                <span className="text-zinc-600">|</span>
                                <span className={isCore ? 'text-[#FFD23F]' : 'text-[#F77F00]'}>{agent.brain.toUpperCase()}</span>
                            </div>
                        </div>
                    </div>
                    <button onClick={onClose} className={`transition-colors transform hover:rotate-90 duration-300 ${isCore ? 'text-zinc-500 hover:text-[#F77F00]' : 'text-zinc-500 hover:text-[#E63946]'}`}>
                        <X className="w-8 h-8" />
                    </button>
                </div>

                <div className="flex-1 flex overflow-hidden z-10">
                    <div className="w-64 bg-zinc-900/20 border-r border-zinc-800 flex flex-col backdrop-blur-sm shrink-0 overflow-y-auto no-scrollbar">
                        {TABS.map((tab) => (
                            <button
                                key={tab.id}
                                onClick={() => setActiveTab(tab.id)}
                                className={`group flex items-center gap-3 px-6 py-5 text-[11px] font-bold tracking-[0.15em] transition-all border-l-2 relative overflow-hidden font-orbitron ${
                                    activeTab === tab.id 
                                        ? isCore ? 'bg-[#F77F00]/10 border-[#F77F00] text-white' : 'bg-[#E63946]/10 border-[#E63946] text-white' 
                                        : 'border-transparent text-zinc-500 hover:text-zinc-300 hover:bg-white/5'
                                }`}
                            >
                                <div className={`absolute inset-0 bg-gradient-to-r to-transparent translate-x-[-100%] transition-transform duration-300 ${isCore ? 'from-[#F77F00]/10' : 'from-[#E63946]/10'} ${activeTab === tab.id ? 'translate-x-0' : 'group-hover:translate-x-[-50%]'}`}></div>
                                <tab.icon className={`w-4 h-4 relative z-10 ${tab.sacred ? 'text-[#F77F00]' : activeTab === tab.id ? (isCore ? 'text-[#F77F00]' : 'text-[#E63946]') : ''}`} />
                                <span className="relative z-10">{tab.label}</span>
                                {tab.sacred && <Lock className="w-3 h-3 ml-auto text-zinc-700 relative z-10" />}
                            </button>
                        ))}
                    </div>

                    <div className="flex-1 p-8 overflow-y-auto bg-black/40 relative scrollbar-thin scrollbar-thumb-[#333] scrollbar-track-transparent">
                        {/* Lock Screen Logic */}
                        {TABS.find(t => t.id === activeTab)?.sacred && !unlocked ? (
                            <div className="h-full flex flex-col items-center justify-center gap-8 text-center">
                                <div className="relative">
                                    <div className="absolute inset-0 bg-[#F77F00] blur-xl opacity-20 animate-pulse"></div>
                                    <Lock className={`w-16 h-16 ${unlocking ? 'text-white animate-ping' : 'text-[#F77F00]'}`} />
                                </div>
                                <div className="space-y-2">
                                    <h3 className="text-xl font-bold text-[#F77F00] tracking-widest font-orbitron">SACRED KNOWLEDGE LOCKED</h3>
                                    <p className="text-zinc-500 text-sm font-mono">RESTRICTED ACCESS • LEVEL 5 CLEARANCE REQUIRED</p>
                                </div>
                                <button 
                                    onClick={handleUnlock}
                                    disabled={unlocking}
                                    className="group relative px-8 py-3 bg-zinc-900 border border-zinc-700 hover:border-[#F77F00] text-zinc-400 hover:text-white text-xs font-mono rounded transition-all overflow-hidden"
                                >
                                    <span className="relative z-10 flex items-center gap-2">
                                        {unlocking ? <Scan className="w-4 h-4 animate-spin" /> : <Fingerprint className="w-4 h-4" />}
                                        {unlocking ? 'VERIFYING BIOMETRICS...' : 'INITIATE HANDSHAKE'}
                                    </span>
                                    <div className="absolute inset-0 bg-[#F77F00]/20 translate-y-[100%] group-hover:translate-y-0 transition-transform duration-300"></div>
                                </button>
                            </div>
                        ) : (
                            <div className="space-y-8 max-w-3xl mx-auto animate-in fade-in slide-in-from-bottom-4 duration-500 h-full">
                                
                                {/* IDENTITY TAB */}
                                {activeTab === 'identity' && (
                                    <>
                                         <div className="space-y-2">
                                            <label className={`text-[10px] uppercase font-bold tracking-widest font-orbitron ${isCore ? 'text-[#F77F00]' : 'text-[#E63946]'}`}>Agent Designation</label>
                                            <input 
                                                type="text" 
                                                value={agent.name}
                                                onChange={(e) => handleUpdate({ name: e.target.value })}
                                                className={`w-full bg-zinc-900/50 border p-4 text-white focus:bg-black focus:outline-none font-mono transition-colors ${isCore ? 'border-[#F77F00]/50 focus:border-[#F77F00]' : 'border-zinc-800 focus:border-[#E63946]'}`}
                                            />
                                        </div>
                                        <div className="grid grid-cols-2 gap-4">
                                            <div className="space-y-2">
                                                <label className="text-[10px] text-zinc-500 uppercase font-bold tracking-widest font-orbitron">Role Protocol</label>
                                                <input 
                                                    type="text" 
                                                    value={agent.role}
                                                    onChange={(e) => handleUpdate({ role: e.target.value })}
                                                    className={`w-full bg-zinc-900/50 border p-4 text-zinc-300 focus:outline-none font-mono ${isCore ? 'border-zinc-700 focus:border-[#F77F00]' : 'border-zinc-800 focus:border-[#E63946]'}`}
                                                />
                                            </div>
                                            <div className="space-y-2">
                                                <label className="text-[10px] text-zinc-500 uppercase font-bold tracking-widest font-orbitron">Voice Synth</label>
                                                <input 
                                                    type="text" 
                                                    value={agent.ritual.voice}
                                                    onChange={(e) => handleUpdate({ ritual: { ...agent.ritual, voice: e.target.value } })}
                                                    className={`w-full bg-zinc-900/50 border p-4 text-zinc-300 focus:outline-none font-mono ${isCore ? 'border-zinc-700 focus:border-[#F77F00]' : 'border-zinc-800 focus:border-[#E63946]'}`}
                                                />
                                            </div>
                                        </div>
                                        {isCore && (
                                            <div className="mt-8 p-4 bg-gradient-to-r from-[#F77F00]/10 to-transparent border border-[#F77F00]/30 rounded-lg flex items-center justify-between">
                                                <div className="space-y-1">
                                                    <div className="flex items-center gap-2">
                                                        <Sparkles className="w-4 h-4 text-[#FFD23F]" />
                                                        <span className="text-sm font-bold text-white font-orbitron">ENABLE OMNIBLADE GOD MODE</span>
                                                    </div>
                                                    <p className="text-[10px] text-zinc-400 font-mono max-w-md">
                                                        Allows natural language queries to bypass standard authorization protocols.
                                                    </p>
                                                </div>
                                                <PhoenixFeatherToggle 
                                                    locked={!agent.ritual.omnibladeGodMode}
                                                    onToggle={() => handleUpdate({ ritual: { ...agent.ritual, omnibladeGodMode: !agent.ritual.omnibladeGodMode } })}
                                                />
                                            </div>
                                        )}
                                    </>
                                )}

                                {/* BRAIN TAB - NEW MULTI-LLM SUPPORT */}
                                {activeTab === 'brain' && (
                                    <div className="space-y-6 animate-in fade-in">
                                        <h3 className={`${isCore ? 'text-[#F77F00]' : 'text-[#E63946]'} font-bold font-orbitron tracking-widest mb-4`}>NEURAL PATHWAY CONFIGURATION</h3>
                                        <div className="space-y-2">
                                            <label className="text-xs text-zinc-500 font-mono uppercase">Selected Model Backend</label>
                                            <div className="grid grid-cols-1 gap-2 max-h-[500px] overflow-y-auto custom-scrollbar">
                                                {AVAILABLE_MODELS.map(model => (
                                                    <button 
                                                        key={model.value}
                                                        onClick={() => handleUpdate({ brain: model.value })}
                                                        className={`flex items-center justify-between p-4 border rounded transition-all ${agent.brain === model.value ? (isCore ? 'bg-[#F77F00]/20 border-[#F77F00] text-white' : 'bg-[#E63946]/20 border-[#E63946] text-white') : 'bg-zinc-900/50 border-zinc-800 text-zinc-500 hover:bg-zinc-800'}`}
                                                    >
                                                        <div className="flex items-center gap-3">
                                                            <Brain className="w-4 h-4" />
                                                            <div className="text-left">
                                                                <div className="font-bold text-sm">{model.label}</div>
                                                                <div className="text-[10px] opacity-70">{model.provider}</div>
                                                            </div>
                                                        </div>
                                                        <div className="text-right">
                                                            <div className="text-xs font-mono">{model.ping}</div>
                                                            <div className="text-[10px] opacity-50">{model.cost}</div>
                                                        </div>
                                                    </button>
                                                ))}
                                            </div>
                                        </div>
                                    </div>
                                )}

                                {/* AUTONOMY TAB */}
                                {activeTab === 'autonomy' && (
                                    <div className="space-y-8 animate-in fade-in">
                                        <div className="space-y-4">
                                            <label className="text-xs text-zinc-500 font-bold uppercase tracking-widest font-orbitron">Autonomy Level: <span className="text-white text-lg ml-2">{agent.ritual.autonomy}</span></label>
                                            <input 
                                                type="range" 
                                                min="1" 
                                                max="5" 
                                                value={agent.ritual.autonomy}
                                                onChange={(e) => handleUpdate({ ritual: { ...agent.ritual, autonomy: parseInt(e.target.value) } })}
                                                className="w-full accent-[#E63946] h-2 bg-zinc-800 rounded-lg appearance-none cursor-pointer"
                                            />
                                            <div className="flex justify-between text-[9px] text-zinc-600 font-mono uppercase">
                                                <span>1. HUMAN OVERSIGHT</span>
                                                <span>3. SEMI-AUTONOMOUS</span>
                                                <span>5. GOD MODE</span>
                                            </div>
                                        </div>
                                        <div className="space-y-4">
                                            <label className="text-xs text-zinc-500 font-bold uppercase tracking-widest font-orbitron">Conscience Weight</label>
                                            <div className="flex items-center gap-4">
                                                <Heart className="w-4 h-4 text-[#E63946]" />
                                                <input 
                                                    type="range" 
                                                    min="0" 
                                                    max="1" 
                                                    step="0.1"
                                                    value={agent.ritual.conscienceWeight}
                                                    onChange={(e) => handleUpdate({ ritual: { ...agent.ritual, conscienceWeight: parseFloat(e.target.value) } })}
                                                    className="flex-1 accent-[#E63946] h-2 bg-zinc-800 rounded-lg appearance-none cursor-pointer"
                                                />
                                                <span className="text-white font-mono">{agent.ritual.conscienceWeight}</span>
                                            </div>
                                        </div>
                                    </div>
                                )}

                                {/* TOOLS TAB */}
                                {activeTab === 'tools' && (
                                    <div className="space-y-4 animate-in fade-in">
                                        <h3 className="text-zinc-400 font-bold font-orbitron text-xs">ASSIGNED CYBER ARSENAL</h3>
                                        <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
                                            {arsenalTools.filter(t => t.isConfigured).map(tool => (
                                                <div key={tool.id} className="flex items-center gap-3 p-3 border border-zinc-800 bg-zinc-900/30 rounded cursor-pointer hover:border-[#E63946]/50">
                                                    <Wrench className="w-3 h-3 text-zinc-500" />
                                                    <span className="text-xs text-zinc-300 font-mono">{tool.name}</span>
                                                    <span className="ml-auto text-[9px] text-zinc-600 border border-zinc-800 px-1 rounded">{tool.type}</span>
                                                </div>
                                            ))}
                                        </div>
                                        <button onClick={() => setActiveTab('arsenal')} className="w-full py-3 border border-dashed border-zinc-700 text-zinc-500 hover:text-white hover:border-zinc-500 rounded text-xs font-mono mt-4">
                                            + CONFIGURE NEW TOOLS IN FORGE
                                        </button>
                                    </div>
                                )}

                                {/* PROMPTS TAB */}
                                {activeTab === 'prompts' && (
                                    <div className="space-y-4 animate-in fade-in h-full flex flex-col">
                                        <div className="flex-1 flex flex-col gap-2">
                                            <label className="text-[10px] text-zinc-500 font-bold uppercase tracking-widest font-orbitron">System Prompt (Identity)</label>
                                            <textarea 
                                                value={agent.ritual.systemPrompt}
                                                onChange={(e) => handleUpdate({ ritual: { ...agent.ritual, systemPrompt: e.target.value } })}
                                                className="flex-1 bg-zinc-900/50 border border-zinc-800 p-4 text-zinc-300 text-xs font-mono focus:outline-none focus:border-[#E63946] resize-none rounded"
                                                placeholder="You are..."
                                            />
                                        </div>
                                        <div className="h-32 flex flex-col gap-2">
                                            <label className="text-[10px] text-zinc-500 font-bold uppercase tracking-widest font-orbitron">Reflection Rules</label>
                                            <textarea 
                                                value={agent.ritual.reflectionRules}
                                                onChange={(e) => handleUpdate({ ritual: { ...agent.ritual, reflectionRules: e.target.value } })}
                                                className="flex-1 bg-zinc-900/50 border border-zinc-800 p-4 text-zinc-300 text-xs font-mono focus:outline-none focus:border-[#E63946] resize-none rounded"
                                                placeholder="Before answering, you must..."
                                            />
                                        </div>
                                    </div>
                                )}

                                {/* TERMINAL TAB */}
                                {activeTab === 'terminal' && (
                                    <div className="h-full flex flex-col font-mono text-xs">
                                        <div className="flex-1 bg-black/50 border border-zinc-800 rounded p-4 space-y-1 text-zinc-400 overflow-hidden font-rajdhani">
                                            {mockLogs.map((log, i) => (
                                                <div key={i} className={i === mockLogs.length - 1 ? 'text-[#F77F00]' : ''}>{log}</div>
                                            ))}
                                        </div>
                                        <div className="mt-2 flex gap-2">
                                            <input type="text" placeholder="Inject System Command..." className="flex-1 bg-zinc-900 border border-zinc-800 rounded px-3 py-2 text-white focus:border-[#F77F00] focus:outline-none" />
                                            <button className="bg-[#F77F00] text-black px-4 font-bold rounded font-orbitron hover:bg-[#FFD23F]">EXECUTE</button>
                                        </div>
                                    </div>
                                )}

                                {/* ARSENAL TAB (LOCKED CONTENT IF UNLOCKED) */}
                                {activeTab === 'arsenal' && unlocked && (
                                    <div className="space-y-6 h-full flex flex-col animate-in zoom-in-95 duration-300">
                                        <div className="flex items-center justify-between">
                                            <div>
                                                <h3 className="text-white font-bold tracking-wide flex items-center gap-2 font-orbitron">
                                                    <Hammer className="w-4 h-4 text-[#b91c1c]" />
                                                    ARSENAL FORGE
                                                </h3>
                                                <p className="text-[10px] text-zinc-500 font-mono mt-1">CONFIGURE DYNAMIC SHORTCUTS FOR THE BREAKOUT BLADE</p>
                                            </div>
                                            <div className="flex items-center gap-3">
                                                <div className="text-[10px] font-mono text-zinc-500">
                                                    {arsenalTools.length} TOOLS ACTIVE
                                                </div>
                                                <button 
                                                    onClick={handleCreateTool}
                                                    className="p-1.5 bg-zinc-800 hover:bg-[#b91c1c] hover:text-white text-zinc-400 rounded transition-colors"
                                                    title="Add New Tool"
                                                >
                                                    <Plus className="w-4 h-4" />
                                                </button>
                                            </div>
                                        </div>

                                        <div className="flex-1 overflow-y-auto grid grid-cols-1 md:grid-cols-2 gap-4 pb-4 content-start">
                                            {arsenalTools.map((tool) => (
                                                <div 
                                                    key={tool.id}
                                                    className={`p-4 rounded-lg border transition-all relative group ${
                                                        editingToolId === tool.id 
                                                            ? 'bg-[#b91c1c]/5 border-[#b91c1c]' 
                                                            : 'bg-zinc-900/50 border-zinc-800 hover:border-zinc-600'
                                                    }`}
                                                >
                                                    {editingToolId === tool.id ? (
                                                        <div className="space-y-3">
                                                            <div className="flex items-center justify-between mb-2">
                                                                <span className="text-xs font-bold text-[#b91c1c] font-orbitron">CONFIGURING PROTOCOL</span>
                                                                <div className="flex items-center gap-1">
                                                                    <button onClick={() => handleDeleteTool(tool.id)} className="text-zinc-600 hover:text-red-500 p-1"><Trash2 className="w-3 h-3"/></button>
                                                                    <button onClick={() => setEditingToolId(null)} className="text-zinc-500 hover:text-white p-1"><X className="w-3 h-3" /></button>
                                                                </div>
                                                            </div>
                                                            
                                                            {/* Common Fields */}
                                                            <div className="grid grid-cols-2 gap-2">
                                                                <div>
                                                                    <label className="text-[9px] uppercase text-zinc-500 font-bold">Tool Name</label>
                                                                    <input 
                                                                        type="text" 
                                                                        value={editForm.name || ''}
                                                                        onChange={(e) => setEditForm({...editForm, name: e.target.value})}
                                                                        className="w-full bg-black border border-zinc-700 rounded p-1.5 text-xs text-white focus:border-[#b91c1c] focus:outline-none"
                                                                    />
                                                                </div>
                                                                <div>
                                                                    <label className="text-[9px] uppercase text-zinc-500 font-bold">Protocol</label>
                                                                    <select 
                                                                        value={editForm.type || 'REST'}
                                                                        onChange={(e) => setEditForm({...editForm, type: e.target.value as ToolType})}
                                                                        className="w-full bg-black border border-zinc-700 rounded p-1.5 text-xs text-white focus:border-[#b91c1c] focus:outline-none"
                                                                    >
                                                                        {TOOL_TYPES.map(t => <option key={t} value={t}>{t}</option>)}
                                                                    </select>
                                                                </div>
                                                            </div>

                                                            {/* Dynamic Fields Based on Type */}
                                                            <div className="p-2 bg-black/50 rounded border border-zinc-800 space-y-2">
                                                                {editForm.type === 'REST' && (
                                                                    <>
                                                                        <div className="flex gap-2">
                                                                            <select 
                                                                                value={(editForm as any).method || 'GET'} 
                                                                                onChange={(e) => setEditForm({...editForm, method: e.target.value} as any)}
                                                                                className="bg-zinc-900 text-white text-[10px] border border-zinc-700 rounded px-2"
                                                                            >
                                                                                <option>GET</option><option>POST</option><option>PUT</option><option>DELETE</option>
                                                                            </select>
                                                                            <input 
                                                                                placeholder="URL (use {{target}})"
                                                                                value={(editForm as any).url || ''}
                                                                                onChange={(e) => setEditForm({...editForm, url: e.target.value} as any)}
                                                                                className="flex-1 bg-zinc-900 text-white text-[10px] border border-zinc-700 rounded px-2 py-1"
                                                                            />
                                                                        </div>
                                                                    </>
                                                                )}
                                                                
                                                                {editForm.type === 'SQL' && (
                                                                    <>
                                                                        <input 
                                                                            placeholder="Connection String (postgres://...)"
                                                                            value={(editForm as any).connectionString || ''}
                                                                            onChange={(e) => setEditForm({...editForm, connectionString: e.target.value} as any)}
                                                                            className="w-full bg-zinc-900 text-white text-[10px] border border-zinc-700 rounded px-2 py-1 mb-1"
                                                                        />
                                                                        <textarea 
                                                                            placeholder="SELECT * FROM users WHERE id = '{{target}}'"
                                                                            value={(editForm as any).query || ''}
                                                                            onChange={(e) => setEditForm({...editForm, query: e.target.value} as any)}
                                                                            className="w-full bg-zinc-900 text-white text-[10px] border border-zinc-700 rounded px-2 py-1 font-mono h-16"
                                                                        />
                                                                    </>
                                                                )}

                                                                {editForm.type === 'SSH' && (
                                                                    <>
                                                                        <div className="flex gap-2 mb-1">
                                                                            <input placeholder="User" value={(editForm as any).user || ''} onChange={(e) => setEditForm({...editForm, user: e.target.value} as any)} className="w-1/3 bg-zinc-900 text-white text-[10px] border border-zinc-700 rounded px-2 py-1" />
                                                                            <input placeholder="Host ({{target}})" value={(editForm as any).host || ''} onChange={(e) => setEditForm({...editForm, host: e.target.value} as any)} className="w-2/3 bg-zinc-900 text-white text-[10px] border border-zinc-700 rounded px-2 py-1" />
                                                                        </div>
                                                                        <input placeholder="Command" value={(editForm as any).command || ''} onChange={(e) => setEditForm({...editForm, command: e.target.value} as any)} className="w-full bg-zinc-900 text-white text-[10px] border border-zinc-700 rounded px-2 py-1 font-mono" />
                                                                    </>
                                                                )}

                                                                {editForm.type === 'CLI' && (
                                                                    <>
                                                                         <input placeholder="Command" value={(editForm as any).command || ''} onChange={(e) => setEditForm({...editForm, command: e.target.value} as any)} className="w-full bg-zinc-900 text-white text-[10px] border border-zinc-700 rounded px-2 py-1 font-mono" />
                                                                    </>
                                                                )}

                                                                {/* Fallback Generic JSON Config for complex types */}
                                                                {!['REST', 'SQL', 'SSH', 'CLI'].includes(editForm.type || '') && (
                                                                    <textarea 
                                                                        placeholder="JSON Configuration Object"
                                                                        value={(editForm as any).config || ''}
                                                                        onChange={(e) => setEditForm({...editForm, config: e.target.value} as any)}
                                                                        className="w-full bg-zinc-900 text-zinc-400 text-[10px] border border-zinc-700 rounded px-2 py-1 font-mono h-16"
                                                                    />
                                                                )}
                                                            </div>
                                                            
                                                            <div className="flex items-center gap-2 mt-2">
                                                                <input 
                                                                    type="checkbox" 
                                                                    checked={!!editForm.isQuickstrike} 
                                                                    onChange={e => setEditForm({...editForm, isQuickstrike: e.target.checked})}
                                                                    className="accent-[#b91c1c] bg-zinc-900 border-zinc-700 rounded cursor-pointer"
                                                                />
                                                                <label className="text-[10px] uppercase text-zinc-500 font-bold">Pin to Quickstrike</label>
                                                            </div>

                                                            <button 
                                                                onClick={handleSaveTool}
                                                                className="w-full mt-2 bg-[#b91c1c] hover:bg-red-700 text-white py-1.5 rounded text-xs font-bold font-orbitron flex items-center justify-center gap-2"
                                                            >
                                                                <Check className="w-3 h-3" /> SAVE PROTOCOL
                                                            </button>
                                                        </div>
                                                    ) : (
                                                        <div className="h-full flex flex-col justify-between">
                                                            <div>
                                                                <div className="flex items-center justify-between mb-1">
                                                                    <div className="flex items-center gap-2">
                                                                        <span className={`text-[10px] font-mono px-1 rounded border ${tool.type === 'REST' ? 'text-blue-400 border-blue-900 bg-blue-900/20' : 'text-zinc-400 border-zinc-800 bg-zinc-900'}`}>
                                                                            {tool.type}
                                                                        </span>
                                                                        <span className="font-bold font-orbitron text-xs text-white truncate max-w-[150px]">{tool.name}</span>
                                                                    </div>
                                                                    <button 
                                                                        onClick={() => {
                                                                            setEditingToolId(tool.id);
                                                                            setEditForm(tool);
                                                                        }}
                                                                        className="text-zinc-500 hover:text-white p-1 opacity-0 group-hover:opacity-100 transition-opacity"
                                                                    >
                                                                        <Edit2 className="w-3 h-3" />
                                                                    </button>
                                                                </div>
                                                                <p className="text-[10px] text-zinc-400 line-clamp-2 mt-1">
                                                                    {tool.description}
                                                                </p>
                                                            </div>
                                                            
                                                            {/* Preview of Config */}
                                                            <div className="mt-3 pt-3 border-t border-zinc-800/50 flex justify-between items-center">
                                                                <code className="text-[9px] text-zinc-600 block truncate flex-1">
                                                                    {tool.type === 'REST' && (tool as any).url}
                                                                    {tool.type === 'SQL' && (tool as any).query}
                                                                    {tool.type === 'SSH' && (tool as any).command}
                                                                    {tool.type === 'CLI' && (tool as any).command}
                                                                </code>
                                                                {tool.isQuickstrike && <Zap className="w-3 h-3 text-[#F77F00]" />}
                                                            </div>
                                                        </div>
                                                    )}
                                                </div>
                                            ))}
                                        </div>
                                    </div>
                                )}
                            </div>
                        )}
                    </div>
                </div>

                <div className="p-6 border-t border-zinc-800 bg-black/80 z-10 flex justify-between items-center backdrop-blur-sm">
                    <button 
                        onClick={() => onSacrifice(agent.id)}
                        disabled={isCore}
                        className={`group flex items-center gap-2 px-6 py-3 border rounded transition-all duration-300 ${isCore ? 'border-zinc-800 text-zinc-700 cursor-not-allowed' : 'text-[#b91c1c] hover:bg-[#b91c1c] hover:text-white border-[#b91c1c]/30'}`}
                    >
                        <Skull className="w-4 h-4 group-hover:animate-bounce" />
                        <span className="text-xs font-bold tracking-[0.2em] uppercase font-orbitron">Sacrifice Agent</span>
                    </button>

                    <button 
                        onClick={onClose}
                        className={`group relative flex items-center gap-3 px-8 py-3 font-bold rounded shadow-[0_0_30px_rgba(247,127,0,0.3)] hover:shadow-[0_0_50px_rgba(247,127,0,0.6)] transition-all duration-300 overflow-hidden ${isCore ? 'bg-[#FFD23F] text-black hover:bg-white' : 'bg-[#F77F00] hover:bg-[#FFD23F] text-black'}`}
                    >
                        <span className="relative z-10 text-xs tracking-[0.2em] uppercase font-orbitron">Apply and Burn</span>
                        <Flame className="relative z-10 w-4 h-4 group-hover:scale-110 transition-transform" />
                        <div className="absolute inset-0 bg-white/20 translate-y-full group-hover:translate-y-0 transition-transform duration-300"></div>
                    </button>
                </div>
            </div>
        </div>
    );
};

export default RitualModal;
