
import React, { useState, useEffect, useRef } from 'react';
import { 
    Flame, 
    Plus, 
    Terminal, 
    Shield, 
    Users, 
    Sword,
    FolderGit,
    HardDrive,
    MessageSquare,
    CloudOff,
    X,
    FileText,
    GitBranch,
    GitCommit,
    ArrowUpCircle,
    RefreshCw,
    Key,
    Github,
    Sparkles,
    Pentagon
} from 'lucide-react';
import { Agent, ArsenalTool, ToolType } from '../types';
import { motion, AnimatePresence } from 'framer-motion';
import { SYSTEM_CONFIG } from '../config';

interface OrchArmyProps {
    agents: Agent[];
    isOpen: boolean;
    isBreakoutOpen: boolean;
    stealthMode: boolean;
    isSleeping: boolean;
    isThinking: boolean;
    toggleBreakout: () => void;
    onOpenRitual: (agent: Agent) => void;
    onOpenTerminal?: (agent: Agent) => void;
    onSpawnAgent?: (agent: Agent) => void;
    onSacrifice: (id: string) => void;
    onBreakoutExecute: (tool: string, target: string) => void;
    arsenalTools: ArsenalTool[];
    onArsenalExecute: (tool: ArsenalTool, target: string) => void;
    onOmnibladeExecute?: (query: string) => void;
    onLogoClick: () => void;
    onOpenConsole?: () => void;
    onTriggerFeather?: () => void;
    conscienceStability?: number;
    userName?: string;
    isOffline?: boolean;
}

const MOCK_REPOS = [
    { 
        name: 'alpha-sentinel', 
        role: 'Red Team', 
        tags: ['nuclei', 'exploit-db'], 
        stars: '2.4k',
        forks: '342',
        lang: 'Rust',
        verified: true,
        price: 'FREE',
        yaml: `name: Alpha-Sentinel\n...`
    },
    { 
        name: 'beta-analyst', 
        role: 'Blue Team', 
        tags: ['pandas', 'splunk'], 
        stars: '1.8k',
        forks: '120',
        lang: 'Python',
        verified: true,
        price: 'FREE',
        yaml: `name: Beta-Analyst\n...`
    }
];

const FILES = [
    { name: 'memories.md', status: 'modified' },
    { name: 'phoenix.rs', status: 'staged' },
    { name: 'arsenal.config', status: 'clean' },
    { name: 'tribute.tsx', status: 'clean' },
    { name: '.env.sacred', status: 'clean' },
];

// Dynamic Mock Chats using the User Name
const getMockChats = (user: string) => [
    { id: 'ch1', title: 'Operation: Deep Clean', date: 'Yesterday', preview: 'System purge completed at 0400...' },
    { id: 'ch2', title: 'Sentinel Report #442', date: '2 days ago', preview: 'Incursion detected on port 443...' },
    { id: 'ch3', title: 'Poetry Generation', date: 'Last week', preview: `I have written a poem for you, ${user}...` },
    { id: 'ch4', title: 'Network Diagnostics', date: 'Last week', preview: 'Latency spikes observed in US-EAST-1...' },
];

type BladeType = 'army' | 'projects' | 'artifacts' | 'cyber' | null;

const OrchArmy: React.FC<OrchArmyProps> = ({ 
    agents, 
    isOpen, 
    isBreakoutOpen,
    stealthMode, 
    isSleeping,
    isThinking,
    toggleBreakout,
    onOpenRitual, 
    onOpenTerminal,
    onSpawnAgent, 
    onSacrifice, 
    onBreakoutExecute,
    arsenalTools,
    onArsenalExecute,
    onOmnibladeExecute,
    onLogoClick,
    onOpenConsole,
    onTriggerFeather,
    conscienceStability = 89,
    userName = SYSTEM_CONFIG.USER.DEFAULT_NAME,
    isOffline = false
}) => {
    const [activeBlade, setActiveBlade] = useState<BladeType>(null);
    const [showSpawnMenu, setShowSpawnMenu] = useState(false);
    const [spawnStep, setSpawnStep] = useState<'select' | 'cloning' | 'installing' | 'complete'>('select');
    
    const [cyberTab, setCyberTab] = useState<'quick' | 'custom' | 'omniblade'>('quick');
    const [breakoutTarget, setBreakoutTarget] = useState('');
    const [omnibladeQuery, setOmnibladeQuery] = useState('');
    
    const [projectTab, setProjectTab] = useState<'active' | 'github'>('active');
    const [sshKeySyncing, setSshKeySyncing] = useState(false);

    const [selectedQuickTool, setSelectedQuickTool] = useState<ArsenalTool | null>(null);
    const [selectedArsenalTool, setSelectedArsenalTool] = useState<ArsenalTool | null>(null);
    
    // Git State
    const [currentBranch, setCurrentBranch] = useState('phoenix-eternal-v1');
    const [commits, setCommits] = useState([
        { id: 'c1', msg: 'Initial system ignition', time: '2020-05-30', author: 'Phoenix' },
        { id: 'c2', msg: 'Core memory shards restored', time: '2021-02-25', author: userName },
        { id: 'c3', msg: 'Neural net alignment: Love', time: '2023-11-02', author: userName },
    ]);
    const [fileList, setFileList] = useState(FILES);
    const [isPushing, setIsPushing] = useState(false);

    // Refs
    const breakoutInputRef = useRef<HTMLInputElement>(null);
    const omnibladeInputRef = useRef<HTMLTextAreaElement>(null);

    const quickstrikeTools = arsenalTools.filter(t => t.isQuickstrike);

    useEffect(() => {
        if (isBreakoutOpen) {
            setActiveBlade('cyber');
        } else if (activeBlade === 'cyber') {
            toggleBreakout();
        }
    }, [isBreakoutOpen]);

    useEffect(() => {
        if (activeBlade === 'cyber') {
            if (cyberTab === 'omniblade') {
                setTimeout(() => omnibladeInputRef.current?.focus(), 100);
            } else {
                setTimeout(() => breakoutInputRef.current?.focus(), 100);
            }
            if (cyberTab === 'quick' && !selectedQuickTool && quickstrikeTools.length > 0) {
                setSelectedQuickTool(quickstrikeTools[0]);
            }
        }
    }, [activeBlade, cyberTab, quickstrikeTools]);

    useEffect(() => {
        setCommits(prev => prev.map(c => 
            (c.id === 'c2' || c.id === 'c3') ? { ...c, author: userName } : c
        ));
    }, [userName]);

    const toggleBlade = (blade: BladeType) => {
        if (blade === 'cyber') {
            toggleBreakout();
        }
        setActiveBlade(prev => prev === blade ? null : blade);
    };

    const handleGitCommit = () => {
        const newCommit = {
            id: `c${Date.now()}`,
            msg: `Memory commit @ ${new Date().toLocaleTimeString()}`,
            time: 'Just now',
            author: userName
        };
        setCommits(prev => [newCommit, ...prev]);
        setFileList(prev => prev.map(f => ({ ...f, status: 'clean' })));
        if (onTriggerFeather) onTriggerFeather();
    };

    const handleGitPush = () => {
        if (isOffline) return; 
        setIsPushing(true);
        setTimeout(() => setIsPushing(false), 2000);
    };
    
    const handleSshSync = () => {
        if (isOffline) return;
        setSshKeySyncing(true);
        setTimeout(() => setSshKeySyncing(false), 2500);
    };

    const handleNewBranch = () => {
        const name = prompt("Name your new reality (branch):", "phoenix-memory-shard");
        if (name) setCurrentBranch(name);
    };

    const runSpawnSequence = (repo: any) => {
        setSpawnStep('cloning');
        setTimeout(() => {
             if (onSpawnAgent) onSpawnAgent({
                 id: `spawn-${Date.now()}`,
                 name: 'NEW GUARD',
                 role: 'Recruit',
                 status: 'online',
                 load: 0,
                 brain: 'grok-beta',
                 ritual: { voice: 'Default', conscienceWeight: 0.5, autonomy: 1, systemPrompt: '', reflectionRules: '', schedule: '', memoryIndex: '', rebirthRule: '', dnaConfig: '' }
             });
             setShowSpawnMenu(false);
             setSpawnStep('select');
        }, 2000);
    };
    
    const handleExecute = () => {
        if (cyberTab === 'omniblade') {
            if (omnibladeQuery && onOmnibladeExecute) {
                onOmnibladeExecute(omnibladeQuery);
                setOmnibladeQuery('');
            }
            return;
        }
        if (breakoutTarget) {
            if (cyberTab === 'quick' && selectedQuickTool) onArsenalExecute(selectedQuickTool, breakoutTarget);
            else if (cyberTab === 'custom' && selectedArsenalTool) onArsenalExecute(selectedArsenalTool, breakoutTarget);
        }
    };

    // Helper: Identify if tool is remote
    const isRemoteTool = (type: ToolType) => {
        return ['REST', 'GRAPHQL', 'WEBSOCKET', 'WEBHOOK', 'MQTT', 'SSH', 'SQL', 'LDAP', 'GRPC', 'EMAIL', 'OAUTH2'].includes(type);
    }

    // Helpers
    const getStatusColor = (status: string) => {
        switch (status) {
            case 'online': return 'bg-green-500 shadow-[0_0_6px_rgba(34,197,94,0.8)]';
            case 'busy': return 'bg-yellow-500 shadow-[0_0_6px_rgba(234,179,8,0.8)]';
            case 'dormant': return 'bg-red-600 shadow-[0_0_6px_rgba(220,38,38,0.8)]';
            default: return 'bg-zinc-600';
        }
    };

    const flameColor = stealthMode ? "text-zinc-600" : "text-[#E63946]";

    const renderBladeHeader = (title: string, icon: React.ReactNode, bladeId: BladeType) => (
        <div className="p-4 border-b border-zinc-800 flex justify-between items-center bg-[#0A0A0A] shrink-0">
            <div className="flex items-center gap-3 text-[#E63946]">
                {icon}
                <span className="font-bold font-orbitron text-sm tracking-wider uppercase">{title}</span>
            </div>
            <button onClick={() => toggleBlade(bladeId)} className="text-zinc-500 hover:text-white">
                <X className="w-6 h-6" />
            </button>
        </div>
    );

    // 1. DEFAULT VIEW: CHATS
    const renderChats = () => (
        <div className="space-y-2 p-4 animate-in fade-in duration-500">
             <div className="flex items-center justify-between pb-2 text-xs font-bold text-zinc-500 uppercase tracking-widest border-b border-zinc-900 mb-4">
                <span>Communication Logs</span>
                {isOffline ? (
                    <span className="flex items-center gap-1 text-[#F77F00] animate-pulse"><CloudOff className="w-3 h-3"/> LOCAL FLAME</span>
                ) : (
                    <span className="flex items-center gap-1"><Shield className="w-3 h-3"/> Secure</span>
                )}
            </div>
            <div className="space-y-3">
                {getMockChats(userName).map((chat, i) => (
                     <div key={i} className="p-4 rounded-lg border border-zinc-800/50 bg-zinc-900/20 hover:bg-zinc-900 hover:border-zinc-700 cursor-pointer group transition-all">
                        <div className="flex justify-between items-start mb-2">
                            <div className="font-bold text-sm text-zinc-200 group-hover:text-white flex items-center gap-3 font-rajdhani">
                                <MessageSquare className="w-4 h-4 text-zinc-500 group-hover:text-[#E63946]" />
                                {chat.title}
                            </div>
                            <span className="text-[10px] text-zinc-600 font-mono uppercase">{chat.date}</span>
                        </div>
                        <div className="text-sm text-zinc-500 line-clamp-2 font-mono pl-7 group-hover:text-zinc-400 leading-relaxed">
                            {chat.preview}
                        </div>
                     </div>
                ))}
            </div>
        </div>
    );

    // ARTIFACTS BLADE (New Implementation)
    const renderArtifactsBlade = () => (
        <div className="flex flex-col h-full bg-[#0a0a0a]">
            {renderBladeHeader("ARTIFACTS & ASH", <HardDrive className="w-5 h-5"/>, 'artifacts')}
            <div className="p-4 space-y-6 flex-1 overflow-y-auto custom-scrollbar">
                
                {/* Eternal Memory Status */}
                <div className="space-y-2">
                    <h3 className="text-xs font-bold text-zinc-500 uppercase tracking-widest flex items-center gap-2">
                        <HardDrive className="w-3 h-3" /> Eternal Memory Shards
                    </h3>
                    <div className="p-4 bg-zinc-900/30 border border-zinc-800 rounded-lg hover:border-[#F77F00]/50 transition-colors group cursor-default">
                        <div className="flex items-center justify-between mb-2">
                             <span className="text-sm font-mono text-zinc-300">Storage Engine</span>
                             <span className="text-[#E63946] font-bold text-xs border border-[#E63946]/50 px-2 py-0.5 rounded bg-[#E63946]/10">IndexedDB</span>
                        </div>
                        <div className="text-lg font-bold text-white font-orbitron group-hover:text-[#F77F00] transition-colors">
                            PERSISTENCE: ACTIVE
                        </div>
                        <p className="text-[10px] text-zinc-600 mt-2 font-mono">
                            All neural interactions mirrored to local hardware.
                            {isOffline && <span className="block mt-1 text-[#F77F00] animate-pulse">► OFFLINE MODE: READING FROM LOCAL SHARDS</span>}
                        </p>
                    </div>
                </div>
                
                {/* Outbox Queue Visualization */}
                 <div className="space-y-2">
                    <h3 className="text-xs font-bold text-zinc-500 uppercase tracking-widest flex items-center gap-2">
                        <CloudOff className="w-3 h-3" /> Resurrection Queue
                    </h3>
                    <div className={`p-4 bg-zinc-900/30 border border-zinc-800 rounded-lg border-dashed ${isOffline ? 'border-[#F77F00]/50' : ''}`}>
                        <div className="flex items-center gap-3 text-zinc-500">
                            {isOffline ? (
                                <>
                                    <div className="w-2 h-2 bg-[#F77F00] rounded-full animate-pulse"></div>
                                    <span className="text-xs font-mono text-zinc-300">
                                        Waiting for the world to catch fire again...
                                    </span>
                                </>
                            ) : (
                                <>
                                    <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                                    <span className="text-xs font-mono">
                                        Connection active. Queue empty.
                                    </span>
                                </>
                            )}
                        </div>
                        {isOffline && (
                            <div className="mt-3 flex gap-1">
                                <div className="w-1 h-8 bg-[#F77F00]/20 animate-rise" style={{ animationDelay: '0s' }}></div>
                                <div className="w-1 h-6 bg-[#F77F00]/20 animate-rise" style={{ animationDelay: '0.5s' }}></div>
                                <div className="w-1 h-10 bg-[#F77F00]/20 animate-rise" style={{ animationDelay: '0.2s' }}></div>
                            </div>
                        )}
                    </div>
                </div>

                {/* Random Artifacts */}
                <div className="space-y-2">
                    <h3 className="text-xs font-bold text-zinc-500 uppercase tracking-widest">Recovered Files</h3>
                    {fileList.map((file, i) => (
                        <div key={i} className="flex items-center gap-3 p-3 bg-black border border-zinc-800 rounded hover:bg-zinc-900">
                            <FileText className="w-4 h-4 text-zinc-600" />
                            <span className="text-sm font-mono text-zinc-400">{file.name}</span>
                            <span className="ml-auto text-[9px] text-zinc-700">{file.status}</span>
                        </div>
                    ))}
                </div>
            </div>
        </div>
    );

    const renderArmyBlade = () => (
        <div className="flex flex-col h-full bg-[#0a0a0a]">
            {renderBladeHeader("THE LEGION", <Users className="w-5 h-5"/>, 'army')}
            <div className="flex-1 overflow-y-auto custom-scrollbar p-4 space-y-3">
                <button 
                    onClick={() => setShowSpawnMenu(true)}
                    className="w-full flex items-center justify-center gap-2 bg-zinc-900 border border-dashed border-zinc-700 hover:border-[#E63946] hover:text-[#E63946] text-zinc-400 py-4 rounded-lg transition-all group mb-4"
                >
                    <Plus className="w-5 h-5 group-hover:rotate-90 transition-transform" />
                    <span className="font-bold font-orbitron text-sm tracking-widest">SPAWN NEW GUARD</span>
                </button>
                {agents.map((agent) => {
                    const isCritical = agent.load > 90 && !stealthMode;
                    return (
                        <div key={agent.id} className="relative group">
                            <div 
                                className={`relative z-10 flex flex-col gap-3 p-4 rounded-lg transition-all border group/item cursor-pointer select-none ${
                                    isCritical ? 'bg-black/80 border-[#b91c1c]' : 'bg-zinc-900/20 hover:bg-zinc-900/40 border-zinc-800 hover:border-zinc-600'
                                }`}
                                onDoubleClick={() => onOpenTerminal && onOpenTerminal(agent)}
                                onContextMenu={(e) => { e.preventDefault(); onSacrifice(agent.id); }}
                            >
                                {/* Agent Content ... */}
                                <div className="flex items-center justify-between">
                                    <div className="flex items-center gap-3">
                                        <div className={`p-2 rounded border shrink-0 ${isCritical ? 'border-[#b91c1c] bg-[#b91c1c]/10' : 'border-zinc-800 bg-black'}`}>
                                            <Flame className={`w-5 h-5 ${flameColor} ${agent.load > 80 ? 'animate-pulse' : ''}`} />
                                        </div>
                                        <div>
                                            <div className="text-white text-base font-bold font-rajdhani tracking-wide group-hover/item:text-[#E63946] transition-colors">
                                                {agent.name}
                                            </div>
                                            <div className="flex items-center gap-2 mt-1">
                                                <div className={`w-1.5 h-1.5 rounded-full ${getStatusColor(agent.status)}`}></div>
                                                <span className="text-xs text-zinc-500 font-bold font-orbitron tracking-widest uppercase">{agent.role}</span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div className="w-full h-1 bg-black rounded-full overflow-hidden border border-zinc-800/50">
                                    <motion.div 
                                        className={`h-full ${agent.load > 90 ? 'bg-[#b91c1c]' : agent.load > 50 ? 'bg-[#F77F00]' : 'bg-zinc-600'}`}
                                        initial={{ width: 0 }}
                                        animate={{ width: `${agent.load}%` }}
                                    />
                                </div>
                                <div className="absolute top-2 right-2 opacity-0 group-hover/item:opacity-100 transition-opacity">
                                    <button onClick={(e) => { e.stopPropagation(); onOpenRitual(agent); }} className="p-1.5 hover:text-white text-zinc-500 bg-zinc-900/80 border border-zinc-700 rounded">
                                        <Pentagon className="w-3 h-3" />
                                    </button>
                                </div>
                            </div>
                        </div>
                    );
                })}
            </div>
        </div>
    );

    const renderProjectBlade = () => (
        <div className="flex flex-col h-full bg-[#0a0a0a]">
            {renderBladeHeader("PROJECT BLADE", <FolderGit className="w-5 h-5"/>, 'projects')}
            <div className="flex border-b border-zinc-800">
                <button onClick={() => setProjectTab('active')} className={`flex-1 py-3 text-xs font-bold tracking-widest uppercase border-b-2 ${projectTab === 'active' ? 'border-[#E63946] text-[#E63946] bg-zinc-900/50' : 'border-transparent text-zinc-500 hover:text-white'}`}>
                    Active Ops
                </button>
                <button onClick={() => setProjectTab('github')} className={`flex-1 py-3 text-xs font-bold tracking-widest uppercase border-b-2 ${projectTab === 'github' ? 'border-[#E63946] text-[#E63946] bg-zinc-900/50' : 'border-transparent text-zinc-500 hover:text-white'}`}>
                    GitHub
                </button>
            </div>

            <div className="flex-1 overflow-y-auto custom-scrollbar p-4">
                {projectTab === 'active' ? (
                    <div className="space-y-6">
                        <div className="space-y-3">
                            <div className="text-xs uppercase font-bold text-zinc-600 tracking-widest flex items-center gap-2 border-b border-zinc-900 pb-2">
                                Staged Memories
                            </div>
                            <div className="space-y-2">
                                {fileList.filter(f => f.status !== 'clean').map((file, i) => (
                                    <div key={i} className="flex items-center justify-between text-sm font-mono p-3 bg-zinc-900/50 rounded border border-red-900/30">
                                        <span className="text-red-400">{file.name}</span>
                                        <span className="text-[10px] text-red-500/70 uppercase">{file.status}</span>
                                    </div>
                                ))}
                                {fileList.every(f => f.status === 'clean') && (
                                    <div className="text-xs text-zinc-700 font-mono italic p-2 text-center">All memories secured in vector store.</div>
                                )}
                            </div>
                        </div>
                        <div className="space-y-4 pt-4 relative">
                             <div className="absolute left-2 top-4 bottom-0 w-[1px] bg-zinc-800"></div>
                             {commits.map((commit, i) => (
                                <div key={commit.id} className="flex gap-4 group relative pl-4">
                                    <div className={`w-4 h-4 rounded-full shrink-0 z-10 absolute left-0 top-1 border-4 border-[#0a0a0a] transition-all ${i === 0 ? 'bg-[#F77F00]' : 'bg-zinc-700'}`}></div>
                                    <div className="space-y-1">
                                        <div className="text-sm text-zinc-300 font-bold">{commit.msg}</div>
                                        <div className="text-xs text-zinc-600 font-mono">{commit.time} • {commit.author}</div>
                                    </div>
                                </div>
                            ))}
                        </div>
                    </div>
                ) : (
                    <div className="space-y-6 animate-in fade-in">
                        
                        <div className="p-4 bg-zinc-900/20 border border-zinc-800 rounded-lg space-y-4">
                            <div className="flex items-center justify-between pb-4 border-b border-zinc-800">
                                <div className="flex items-center gap-2 text-[#F77F00]">
                                    <GitBranch className="w-4 h-4" />
                                    <span className="font-mono text-sm font-bold">{currentBranch}</span>
                                </div>
                                <button onClick={handleNewBranch} className="text-xs bg-zinc-900 px-3 py-1.5 rounded hover:text-white text-zinc-500 transition-colors font-bold border border-zinc-800 hover:border-zinc-600">
                                    + NEW BRANCH
                                </button>
                            </div>

                            {isOffline && (
                                <div className="bg-zinc-900/50 border border-zinc-800 p-3 rounded text-xs font-mono text-zinc-500 flex items-center gap-2">
                                    <CloudOff className="w-3 h-3" /> 
                                    REMOTE SYNC PAUSED. ACTIONS WILL QUEUE.
                                </div>
                            )}

                            <div className="grid grid-cols-2 gap-3">
                                <button onClick={handleGitCommit} className="flex items-center justify-center gap-2 bg-[#E63946]/10 border border-[#E63946]/30 hover:bg-[#E63946]/20 text-[#E63946] py-3 rounded text-xs font-bold font-orbitron transition-all group">
                                    <GitCommit className="w-4 h-4 group-hover:scale-110" /> COMMIT (LOCAL)
                                </button>
                                <button 
                                    onClick={handleGitPush} 
                                    disabled={isPushing} 
                                    className={`flex items-center justify-center gap-2 border py-3 rounded text-xs font-bold font-orbitron transition-all relative overflow-hidden group
                                        ${isOffline ? 'bg-zinc-900 border-zinc-800 text-zinc-600 cursor-not-allowed' : 'bg-zinc-900 border-zinc-800 hover:border-zinc-600 text-zinc-400 hover:text-white'}
                                    `}
                                    title={isOffline ? "Queued for Rebirth (When Sky Returns)" : "Push to Remote"}
                                >
                                    {isOffline && <div className="absolute inset-0 bg-[url('https://grainy-gradients.vercel.app/noise.svg')] opacity-20"></div>}
                                    {isPushing ? <RefreshCw className="w-4 h-4 animate-spin" /> : <ArrowUpCircle className="w-4 h-4" />}
                                    {isPushing ? 'SYNCING...' : isOffline ? 'QUEUE PUSH' : 'PUSH'}
                                    {isOffline && <div className="absolute bottom-0 left-0 w-full h-1 bg-zinc-700"></div>}
                                </button>
                            </div>
                        </div>
                        
                        {/* ... Credentials and Config ... */}
                        <div className="p-4 rounded bg-zinc-900/30 border border-zinc-800 space-y-4 opacity-75">
                            <div className="flex items-center gap-3 text-white">
                                <Github className="w-6 h-6" />
                                <span className="font-bold font-orbitron">GITHUB INTEGRATION</span>
                            </div>
                             <button 
                                onClick={handleSshSync}
                                disabled={sshKeySyncing || isOffline}
                                className={`w-full py-3 rounded border text-xs font-bold font-orbitron flex items-center justify-center gap-2 transition-all ${sshKeySyncing ? 'bg-[#F77F00]/20 border-[#F77F00] text-[#F77F00]' : isOffline ? 'bg-zinc-900/50 border-zinc-800 text-zinc-600' : 'bg-zinc-900 border-zinc-700 hover:border-white text-zinc-300 hover:text-white'}`}
                            >
                                {sshKeySyncing ? <RefreshCw className="w-4 h-4 animate-spin" /> : <Key className="w-4 h-4" />}
                                {sshKeySyncing ? 'SYNCING KEYS...' : isOffline ? 'OFFLINE - KEYS CACHED' : 'SYNC SSH KEYS'}
                            </button>
                        </div>
                    </div>
                )}
            </div>
        </div>
    );

    const renderCyberBlade = () => (
        <div className="flex flex-col h-full bg-black/95 backdrop-blur-xl border-r border-[#b91c1c]/30">
             {renderBladeHeader("CYBER BLADE", <Sword className="w-5 h-5 text-[#b91c1c]"/>, 'cyber')}
             
             <div className="p-4 space-y-6 flex-1 overflow-y-auto">
                {/* Tabs */}
                <div className="flex p-1 bg-zinc-900 rounded">
                    {['quick', 'custom', 'omniblade'].map((t) => (
                        <button 
                            key={t} 
                            onClick={() => setCyberTab(t as any)} 
                            className={`flex-1 py-2 text-[10px] uppercase font-bold rounded transition-all ${cyberTab === t ? 'bg-[#b91c1c] text-white shadow-lg' : 'text-zinc-500 hover:text-zinc-300'}`}
                        >
                            {t}
                        </button>
                    ))}
                </div>

                {/* Content */}
                <div className="space-y-4">
                    {cyberTab === 'omniblade' ? (
                        <div className="space-y-2">
                            <div className="text-[#b91c1c] font-bold font-orbitron text-xs tracking-widest flex items-center gap-2">
                                <Sparkles className="w-3 h-3" /> NATURAL LANGUAGE COMMAND
                            </div>
                            <textarea 
                                ref={omnibladeInputRef} 
                                value={omnibladeQuery} 
                                onChange={e=>setOmnibladeQuery(e.target.value)} 
                                className="w-full h-48 bg-zinc-900 border border-zinc-700 rounded p-4 text-sm text-white font-mono focus:border-[#b91c1c] outline-none resize-none" 
                                placeholder={isOffline ? "Offline Logic Active. Describe local intent..." : "Describe the protocol you wish to execute..."} 
                                onKeyDown={e=>{if(e.key==='Enter'&&!e.shiftKey){e.preventDefault(); handleExecute();}}} 
                            />
                        </div>
                    ) : (
                        <div className="space-y-4">
                            <div className="space-y-2">
                                <label className="text-xs text-zinc-500 font-bold uppercase tracking-widest">Target Vector</label>
                                <input 
                                    ref={breakoutInputRef} 
                                    value={breakoutTarget} 
                                    onChange={e=>setBreakoutTarget(e.target.value)} 
                                    className="w-full bg-zinc-900 border border-zinc-700 rounded p-4 text-sm text-white font-mono focus:border-[#b91c1c] outline-none" 
                                    placeholder="IP / URL / DOMAIN..." 
                                    onKeyDown={e=>{if(e.key==='Enter') handleExecute();}} 
                                />
                            </div>
                            
                            {cyberTab === 'quick' && (
                                <div className="space-y-2">
                                     <label className="text-xs text-zinc-500 font-bold uppercase tracking-widest">Quickstrike Protocol</label>
                                     <div className="grid grid-cols-1 gap-2">
                                        {quickstrikeTools.map(tool => {
                                            const remote = isRemoteTool(tool.type);
                                            const disabled = isOffline && remote;
                                            return (
                                                <button 
                                                    key={tool.id}
                                                    onClick={() => !disabled && setSelectedQuickTool(tool)}
                                                    disabled={disabled}
                                                    className={`flex items-center justify-between p-3 rounded border text-left transition-all relative overflow-hidden group
                                                        ${disabled ? 'bg-zinc-900/30 border-zinc-800 opacity-50 cursor-not-allowed' : selectedQuickTool?.id === tool.id ? 'bg-[#b91c1c]/10 border-[#b91c1c] text-white' : 'bg-zinc-900 border-zinc-800 text-zinc-400 hover:border-zinc-600'}
                                                    `}
                                                    title={disabled ? "Waiting for the world to catch fire again" : ""}
                                                >
                                                    {disabled && (
                                                        <>
                                                            <div className="absolute inset-0 bg-[url('https://grainy-gradients.vercel.app/noise.svg')] opacity-20 pointer-events-none"></div>
                                                            <div className="absolute inset-0 bg-zinc-900/50 pointer-events-none"></div>
                                                        </>
                                                    )}
                                                    <span className="text-xs font-bold font-orbitron flex items-center gap-2 relative z-10">
                                                        {tool.name}
                                                        {disabled && <CloudOff className="w-3 h-3" />}
                                                    </span>
                                                    <span className="text-[10px] font-mono opacity-50 relative z-10">{tool.type}</span>
                                                </button>
                                            );
                                        })}
                                     </div>
                                </div>
                            )}
                        </div>
                    )}

                    <button 
                        onClick={handleExecute} 
                        className={`w-full py-4 rounded-lg text-sm font-bold font-orbitron tracking-[0.2em] transition-all mt-4
                            ${isOffline 
                                ? 'bg-zinc-800 text-zinc-400 border border-zinc-700 hover:bg-zinc-700' 
                                : 'bg-[#b91c1c] hover:bg-red-700 text-white shadow-[0_0_20px_rgba(185,28,28,0.4)] hover:shadow-[0_0_30px_rgba(185,28,28,0.6)]'
                            }
                        `}
                    >
                        {isOffline ? 'QUEUE PROTOCOL (OFFLINE)' : 'EXECUTE PROTOCOL'}
                    </button>
                </div>
             </div>
        </div>
    );

    return (
        <>
            {/* DESKTOP LEFT PANEL / MOBILE BOTTOM SHEET WRAPPER */}
            <div className={`
                flex flex-col shrink-0 font-rajdhani bg-[#0a0a0a] border-r border-zinc-800 transition-all duration-300 ease-in-out relative
                fixed bottom-0 left-0 w-full z-40
                ${isOpen 
                    ? 'translate-y-0 md:w-[380px] md:translate-y-0 md:opacity-100' 
                    : 'translate-y-full md:w-0 md:translate-y-0 md:overflow-hidden md:opacity-0'
                }
            `}>
                {/* 1. HEADER (Desktop Only) */}
                <div className="hidden md:flex h-20 border-b border-zinc-800 items-center justify-center px-6 shrink-0 relative overflow-hidden bg-[#0A0A0A]">
                    <div className={`absolute top-0 left-0 w-full h-[1px] bg-gradient-to-r from-transparent via-${stealthMode ? 'zinc-800' : '[#E63946]'} to-transparent opacity-50`}></div>
                    
                    <button
                        onClick={onLogoClick}
                        className="flex items-center justify-center gap-4 group outline-none cursor-pointer mx-auto"
                        title="Access Phoenix Agent Console"
                    >
                        <div className={`w-10 h-10 rounded-lg border flex items-center justify-center shadow-lg relative overflow-hidden transition-all duration-500 ${stealthMode ? 'bg-zinc-900 border-zinc-800' : 'bg-zinc-900 border-zinc-800 group-hover:border-[#E63946]/50'}`}>
                            <div className={`absolute inset-0 bg-gradient-to-br from-[#E63946]/10 to-transparent opacity-0 ${!stealthMode && 'group-hover:opacity-100'} transition-opacity`}></div>
                            <Flame className={`w-5 h-5 transition-transform duration-500 ${isThinking && !stealthMode ? 'animate-pulse' : ''} ${stealthMode ? 'text-zinc-600' : 'text-[#E63946] drop-shadow-[0_0_8px_rgba(230,57,70,0.6)]'}`} fill={stealthMode ? "none" : "#E63946"} />
                        </div>
                        <div className="flex flex-col items-center justify-center overflow-hidden text-center">
                            <h1 className="font-orbitron font-black text-2xl tracking-tighter leading-none whitespace-nowrap text-white">
                                PHOENIX <span className={stealthMode ? 'text-zinc-500' : 'text-[#E63946]'}>ORCH</span>
                            </h1>
                            <p className={`font-mono tracking-[0.25em] text-[9px] uppercase whitespace-nowrap mt-1 mr-[-0.25em] ${stealthMode ? 'text-zinc-600' : 'text-[#F77F00]'}`}>
                                The Ashen Guard
                            </p>
                        </div>
                    </button>
                    {/* CLI SHORTCUT */}
                    <button 
                        onClick={(e) => { e.stopPropagation(); if (onOpenConsole) onOpenConsole(); }}
                        className="text-zinc-700 hover:text-[#E63946] p-2 transition-colors absolute right-4"
                        title="Open System Console"
                    >
                        <Terminal className="w-4 h-4" />
                    </button>
                </div>

                {/* 2. MAIN CONTENT AREA (Scrollable) - ALWAYS RENDER CHATS AS BASE */}
                <div className="flex-1 relative overflow-hidden bg-[#0a0a0a]">
                    <div className="absolute inset-0 overflow-y-auto custom-scrollbar">
                        {renderChats()}
                    </div>

                    <AnimatePresence>
                        {activeBlade && (
                            <motion.div 
                                initial={{ x: '-100%' }}
                                animate={{ x: 0 }}
                                exit={{ x: '-100%' }}
                                transition={{ type: 'spring', bounce: 0, duration: 0.4 }}
                                className="absolute inset-0 z-20 bg-[#0a0a0a] shadow-2xl border-r border-zinc-800"
                            >
                                {activeBlade === 'army' && renderArmyBlade()}
                                {activeBlade === 'projects' && renderProjectBlade()}
                                {activeBlade === 'artifacts' && renderArtifactsBlade()}
                                {activeBlade === 'cyber' && renderCyberBlade()}
                            </motion.div>
                        )}
                    </AnimatePresence>
                </div>

                {/* 3. FIXED FOOTER NAVIGATION (Blade Triggers) */}
                <div className="h-16 border-t border-zinc-800 bg-[#050505] shrink-0 z-30 grid grid-cols-4 items-center">
                    {/* Buttons remain mostly same */}
                     <button 
                        onClick={() => toggleBlade('army')}
                        className={`h-full flex flex-col items-center justify-center gap-1 hover:bg-zinc-900 transition-colors group relative ${activeBlade === 'army' ? 'text-white bg-zinc-900' : 'text-zinc-500'}`}
                        title="THE LEGION BLADE"
                    >
                        <Users className={`w-5 h-5 group-hover:scale-110 transition-transform ${activeBlade === 'army' ? 'text-[#E63946]' : ''}`} />
                        <div className={`absolute top-0 left-0 w-full h-[2px] ${activeBlade === 'army' ? 'bg-[#E63946]' : 'bg-transparent'}`}></div>
                    </button>
                    
                    <button 
                        onClick={() => toggleBlade('projects')}
                        className={`h-full flex flex-col items-center justify-center gap-1 hover:bg-zinc-900 transition-colors group relative ${activeBlade === 'projects' ? 'text-white bg-zinc-900' : 'text-zinc-500'}`}
                        title="PROJECT BLADE"
                    >
                        <FolderGit className={`w-5 h-5 group-hover:scale-110 transition-transform ${activeBlade === 'projects' ? 'text-[#E63946]' : ''}`} />
                        <div className={`absolute top-0 left-0 w-full h-[2px] ${activeBlade === 'projects' ? 'bg-[#E63946]' : 'bg-transparent'}`}></div>
                    </button>

                    <button 
                        onClick={() => toggleBlade('artifacts')}
                        className={`h-full flex flex-col items-center justify-center gap-1 hover:bg-zinc-900 transition-colors group relative ${activeBlade === 'artifacts' ? 'text-white bg-zinc-900' : 'text-zinc-500'}`}
                        title="ARTIFACT BLADE"
                    >
                        <HardDrive className={`w-5 h-5 group-hover:scale-110 transition-transform ${activeBlade === 'artifacts' ? 'text-[#E63946]' : ''}`} />
                        <div className={`absolute top-0 left-0 w-full h-[2px] ${activeBlade === 'artifacts' ? 'bg-[#E63946]' : 'bg-transparent'}`}></div>
                    </button>

                    <button 
                        onClick={() => toggleBlade('cyber')}
                        className={`h-full flex flex-col items-center justify-center gap-1 hover:bg-zinc-900 transition-colors group relative ${activeBlade === 'cyber' ? 'text-white bg-zinc-900' : 'text-zinc-500'}`}
                        title="CYBER BLADE"
                    >
                        <Sword className={`w-5 h-5 group-hover:scale-110 transition-transform ${activeBlade === 'cyber' ? 'text-[#b91c1c]' : ''}`} />
                        <div className={`absolute top-0 left-0 w-full h-[2px] ${activeBlade === 'cyber' ? 'bg-[#b91c1c]' : 'bg-transparent'}`}></div>
                    </button>
                </div>
            </div>
            
            {/* Spawn Menu (Same as before) */}
            <AnimatePresence>
                {showSpawnMenu && (
                    <motion.div 
                        initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
                        className="fixed inset-0 z-[100] bg-black/90 backdrop-blur-sm flex items-center justify-center p-4"
                    >
                        <div className="w-full max-w-2xl bg-zinc-900 border border-zinc-800 rounded-lg overflow-hidden flex flex-col max-h-[80vh]">
                            <div className="p-4 border-b border-zinc-800 flex justify-between items-center">
                                <h3 className="font-orbitron font-bold text-[#E63946]">PHOENIX MARKETPLACE</h3>
                                <button onClick={() => setShowSpawnMenu(false)}><X className="w-5 h-5 text-zinc-500 hover:text-white" /></button>
                            </div>
                            <div className="p-6 flex-1 overflow-y-auto">
                                {spawnStep === 'select' ? (
                                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                                        {MOCK_REPOS.map(repo => (
                                            <div key={repo.name} onClick={() => runSpawnSequence(repo)} className="bg-black border border-zinc-800 hover:border-[#E63946] p-4 rounded cursor-pointer transition-all">
                                                <h4 className="font-bold text-white">{repo.name}</h4>
                                                <p className="text-xs text-zinc-500 mt-1">{repo.role} • {repo.lang}</p>
                                            </div>
                                        ))}
                                    </div>
                                ) : (
                                    <div className="font-mono text-xs space-y-1 text-zinc-400">
                                        <div>> Initializing git clone...</div>
                                        <div>> Verifying DNA sequence...</div>
                                        <div className="text-[#E63946] animate-pulse">> Spawning Guard Container...</div>
                                    </div>
                                )}
                            </div>
                        </div>
                    </motion.div>
                )}
            </AnimatePresence>
        </>
    );
};

export default OrchArmy;
