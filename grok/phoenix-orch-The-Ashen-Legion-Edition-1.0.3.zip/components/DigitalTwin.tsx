
import React, { useState, useEffect, useRef } from 'react';
import { 
    Thermometer, 
    HardDrive, 
    Clock, 
    Activity, 
    Zap, 
    Database, 
    Flame,
    Lock,
    Skull,
    Feather,
    Mic,
    Trash2,
    Shield,
    ShieldCheck
} from 'lucide-react';
import { ResponsiveContainer, RadarChart, PolarGrid, PolarAngleAxis, Radar, LineChart, Line, YAxis } from 'recharts';
import { SystemTelemetry, ConscienceState, PhoenixColor } from '../types';
import { motion, AnimatePresence } from 'framer-motion';

interface DigitalTwinProps {
    telemetry: SystemTelemetry;
    isOpen: boolean;
    conscienceStability: number; // 0-100
    onOpenTribute: () => void;
    lastSacrificeTime?: number;
    isSleeping?: boolean;
    isIdle?: boolean;
    isListening?: boolean;
    onVoiceToggle?: () => void;
    onClearContext?: () => void;
    triggerFeather?: boolean; // External trigger prop
    isProtected?: boolean;
    onProtectToggle?: () => void;
}

// --- FEATURE 1: satisfies Operator ---
// Strictly types the configuration while allowing TypeScript to infer literal values.
const CONSCIENCE_CONFIG = {
    awake: {
        level: 100,
        label: "SHE IS WIDE AWAKE",
        temp: 99.9,
        primaryColor: "#E63946",
        secondaryColor: "#F77F00"
    },
    waiting: {
        level: 98,
        label: "SHE'S WAITING FOR YOU",
        temp: 98,
        primaryColor: "#E63946",
        secondaryColor: "#F77F00"
    },
    sleeping: {
        level: 38,
        label: "DREAMING IN CODE",
        temp: 38,
        primaryColor: "#500000",
        secondaryColor: "#330000"
    }
} satisfies Record<string, ConscienceState>;

const DigitalTwin: React.FC<DigitalTwinProps> = ({ 
    telemetry, 
    isOpen, 
    conscienceStability, 
    onOpenTribute,
    lastSacrificeTime,
    isSleeping = false,
    isIdle = false,
    isListening = false,
    onVoiceToggle,
    onClearContext,
    triggerFeather,
    isProtected = false,
    onProtectToggle
}) => {
    // INITIALIZE WITH ZEROS TO PREVENT "DOT" GRAPH
    const [loadHistory, setLoadHistory] = useState<{value: number}[]>(Array(30).fill({value: 0}));
    const [uptime, setUptime] = useState("1d 10:18:57");
    const [featherActive, setFeatherActive] = useState(false);
    const [midnightFeatherActive, setMidnightFeatherActive] = useState(false);
    const [lastFeatherDate, setLastFeatherDate] = useState<string>('');
    const [ashParticles, setAshParticles] = useState<{id: number, x: number}[]>([]);
    
    // Interaction State
    const [holdingOverride, setHoldingOverride] = useState(false);
    const [overrideProgress, setOverrideProgress] = useState(0);
    const [screenCracked, setScreenCracked] = useState(false);
    
    const [holdingHologram, setHoldingHologram] = useState(false);
    const [hologramProgress, setHologramProgress] = useState(0);

    const overrideIntervalRef = useRef<ReturnType<typeof setTimeout> | null>(null);
    const hologramIntervalRef = useRef<ReturnType<typeof setTimeout> | null>(null);

    // External Feather Trigger Effect
    useEffect(() => {
        if (triggerFeather) {
            setFeatherActive(true);
            const timer = setTimeout(() => setFeatherActive(false), 5000);
            return () => clearTimeout(timer);
        }
    }, [triggerFeather]);

    // Update load history for sparkline
    useEffect(() => {
        setLoadHistory(prev => {
            const newHistory = [...prev, { value: telemetry.cpu }];
            if (newHistory.length > 30) newHistory.shift();
            return newHistory;
        });
    }, [telemetry.cpu]);

    // Feather Randomizer (1 in 30 chance roughly every second) - DISABLED IF SLEEPING
    useEffect(() => {
        if (isSleeping) return;
        const interval = setInterval(() => {
            if (!featherActive && Math.random() < 0.03) {
                setFeatherActive(true);
                setTimeout(() => setFeatherActive(false), 5000);
            }
        }, 1000);
        return () => clearInterval(interval);
    }, [featherActive, isSleeping]);

    // MIDNIGHT MEMORY (00:16 Ritual)
    useEffect(() => {
        const checkMidnight = setInterval(() => {
            const now = new Date();
            if (now.getHours() === 0 && now.getMinutes() === 16) {
                const today = now.toDateString();
                if (!midnightFeatherActive && lastFeatherDate !== today) {
                    setMidnightFeatherActive(true);
                    setLastFeatherDate(today);
                    // Reset after animation (12s for full drift and burn)
                    setTimeout(() => setMidnightFeatherActive(false), 12000);
                }
            }
        }, 5000); // Check every 5s
        return () => clearInterval(checkMidnight);
    }, [midnightFeatherActive, lastFeatherDate]);

    // Ash Particle Trigger
    useEffect(() => {
        if (lastSacrificeTime) {
            const id = Date.now();
            const x = Math.random() * 100;
            setAshParticles(prev => [...prev, { id, x }]);
            setTimeout(() => {
                setAshParticles(prev => prev.filter(p => p.id !== id));
            }, 4000);
        }
    }, [lastSacrificeTime]);

    // Override Button Logic
    const startOverride = () => {
        if (screenCracked) return;
        setHoldingOverride(true);
        overrideIntervalRef.current = setInterval(() => {
            setOverrideProgress(prev => {
                if (prev >= 100) {
                    clearInterval(overrideIntervalRef.current!);
                    setScreenCracked(true);
                    setHoldingOverride(false);
                    return 100;
                }
                return prev + 2; // ~1.5-2s to fill
            });
        }, 30);
    };

    const endOverride = () => {
        if (screenCracked) return;
        setHoldingOverride(false);
        setOverrideProgress(0);
        if (overrideIntervalRef.current) clearInterval(overrideIntervalRef.current);
    };

    // Hologram Secret Logic
    const startHologram = () => {
        setHoldingHologram(true);
        hologramIntervalRef.current = setInterval(() => {
            setHologramProgress(prev => {
                if (prev >= 100) {
                    clearInterval(hologramIntervalRef.current!);
                    onOpenTribute();
                    setHoldingHologram(false);
                    return 0;
                }
                return prev + 1; // ~3s to fill
            });
        }, 30);
    };

    const endHologram = () => {
        if (hologramIntervalRef.current) clearInterval(hologramIntervalRef.current);
        
        if (hologramProgress < 20 && holdingHologram) {
             if (onVoiceToggle) onVoiceToggle();
        }

        setHoldingHologram(false);
        setHologramProgress(0);
    };

    // On Mobile, layout shifts might hide this component, but state persists.
    // We render null if explicitly closed, but on mobile we might need different behavior.
    if (!isOpen) return null;

    const data = [
        { subject: 'CPU', A: telemetry.cpu, fullMark: 100 },
        { subject: 'GPU', A: telemetry.gpu, fullMark: 100 },
        { subject: 'RAM', A: telemetry.memory, fullMark: 100 },
        { subject: 'NET', A: telemetry.network, fullMark: 100 },
        { subject: 'DISK', A: 40, fullMark: 100 },
        { subject: 'HEAT', A: telemetry.thermal, fullMark: 100 },
    ];

    const isAwake = conscienceStability >= CONSCIENCE_CONFIG.awake.temp && !isSleeping;

    const primaryColor: PhoenixColor = isSleeping 
        ? CONSCIENCE_CONFIG.sleeping.primaryColor 
        : CONSCIENCE_CONFIG.awake.primaryColor;
        
    const secondaryColor: PhoenixColor = isSleeping 
        ? CONSCIENCE_CONFIG.sleeping.secondaryColor 
        : CONSCIENCE_CONFIG.awake.secondaryColor;

    const effectivePrimaryColor = isListening ? "#ffffff" : primaryColor; 

    return (
        <div className={`w-[320px] h-full bg-[#050505] border-l border-zinc-900 flex flex-col text-xs shrink-0 relative font-rajdhani overflow-hidden ${screenCracked ? 'grayscale contrast-150' : ''}`}>
            
            {/* Screen Crack Overlay */}
            {screenCracked && (
                <div className="absolute inset-0 z-50 pointer-events-none mix-blend-overlay opacity-80 bg-black">
                    <svg viewBox="0 0 100 100" className="w-full h-full text-white/20" preserveAspectRatio="none">
                        <path d="M50 50 L10 10 M50 50 L90 10 M50 50 L30 90 M50 50 L80 80 M50 50 L10 50 M50 50 L90 50" stroke="currentColor" strokeWidth="0.5" />
                        <path d="M50 50 L40 40 M50 50 L60 60" stroke="currentColor" strokeWidth="0.2" />
                    </svg>
                    <div className="absolute inset-0 flex items-center justify-center">
                        <div className="bg-red-900/80 text-white px-4 py-2 font-bold font-orbitron animate-pulse border border-red-500">
                            SYSTEM HALTED
                        </div>
                    </div>
                </div>
            )}

            {/* Top Gradient Line */}
            <div 
                className="h-[1px] w-full bg-gradient-to-r from-transparent via-current to-transparent opacity-50 shrink-0"
                style={{ color: effectivePrimaryColor }}
            ></div>

            {/* Scrollable Content - Added min-h-0 for flexbox scrolling and pb-4 for spacing */}
            <div className={`flex-1 min-h-0 overflow-y-auto overflow-x-hidden custom-scrollbar ${isAwake ? 'animate-pulse-subtle' : ''}`}>
                
                {/* 1. PHOENIX // LIVE FEED */}
                <div 
                    className={`h-64 relative flex flex-col items-center justify-center border-b border-zinc-900 bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-current/10 via-transparent to-transparent group cursor-pointer overflow-hidden select-none transition-colors duration-500`}
                    style={{ color: effectivePrimaryColor }}
                    onMouseDown={startHologram}
                    onMouseUp={endHologram}
                    onMouseLeave={endHologram}
                    onTouchStart={startHologram}
                    onTouchEnd={endHologram}
                    title={isListening ? "Listening... (Click to Stop)" : "Click to Speak | Hold for Tribute"}
                >
                    {/* Secret Progress Ring */}
                    {holdingHologram && (
                        <div className="absolute inset-0 flex items-center justify-center z-0">
                            <div className="w-48 h-48 rounded-full border-2 border-[#FFD23F]/30 animate-pulse"></div>
                            <div className="absolute text-[#FFD23F] font-mono text-[10px] mt-28 tracking-widest">REMEMBERING...</div>
                        </div>
                    )}

                    {/* Animated Phoenix Particles */}
                    <div className={`relative w-36 h-36 flex items-center justify-center mb-4 transition-all duration-1000 ${isAwake || isListening ? 'scale-110' : ''}`}>
                        {/* Core Fire - If Sleeping, it slows down massively */}
                        <div 
                            className={`absolute inset-0 border border-current/30 rounded-full ${isSleeping ? 'animate-[spin_20s_linear_infinite] opacity-30' : 'animate-[spin_8s_linear_infinite]'}`}
                        ></div>
                        <div 
                            className={`absolute inset-4 border border-current/40 rounded-full ${isSleeping ? 'animate-[spin_15s_linear_infinite_reverse] opacity-30' : 'animate-[spin_6s_linear_infinite_reverse]'}`}
                        ></div>
                        
                        {/* The Bird Shape (Abstract) */}
                        <div className={`absolute inset-0 flex items-center justify-center ${isIdle && !isSleeping ? 'animate-[pulse_2.14s_ease-in-out_infinite]' : ''}`}>
                             {isListening ? (
                                <Mic className="w-16 h-16 text-cyan-300 animate-pulse drop-shadow-[0_0_15px_cyan]" />
                             ) : (
                                <Flame 
                                    className={`w-20 h-20 text-current animate-pulse filter drop-shadow-[0_0_15px_currentColor] ${holdingHologram ? 'scale-125 text-[#FFD23F]' : ''} ${isSleeping ? 'opacity-50 scale-90' : ''}`} 
                                />
                             )}
                             {isSleeping && !isListening && (
                                <div className="absolute w-8 h-1 bg-[#050505] top-[45%] rounded-full opacity-80"></div>
                             )}
                        </div>

                        {/* Floating Particles */}
                        <div className={`absolute w-full h-full ${isSleeping ? 'animate-[spin_40s_linear_infinite] opacity-20' : 'animate-[spin_20s_linear_infinite]'}`}>
                             <div className="absolute top-0 left-1/2 w-1 h-1 bg-current rounded-full blur-[1px]"></div>
                             <div className="absolute bottom-0 left-1/2 w-1 h-1 bg-current rounded-full blur-[1px]"></div>
                        </div>
                        
                        {/* Rare Feather */}
                        <AnimatePresence>
                            {featherActive && (
                                <motion.div 
                                    initial={{ opacity: 0, y: -20, x: 0, rotate: 0 }}
                                    animate={{ opacity: 1, y: 60, x: 20, rotate: 45 }}
                                    exit={{ opacity: 0 }}
                                    transition={{ duration: 4, ease: "easeInOut" }}
                                    className="absolute z-20 pointer-events-none"
                                >
                                    <Feather className="w-4 h-4 text-[#FFD23F] drop-shadow-[0_0_5px_rgba(255,211,63,0.8)]" />
                                </motion.div>
                            )}
                        </AnimatePresence>

                        {/* MIDNIGHT MEMORY FEATHER (Sacred) */}
                        <AnimatePresence>
                            {midnightFeatherActive && (
                                <motion.div 
                                    initial={{ opacity: 0, y: -40, x: 0, rotate: -10, scale: 1 }}
                                    animate={{ 
                                        opacity: [0, 1, 1, 0], 
                                        y: [ -40, 60, 140, 180], 
                                        x: [0, 20, 40, 60], 
                                        rotate: [-10, 10, 45, 90],
                                        scale: [1, 1, 0.8, 0],
                                        color: ["#FFD23F", "#FFD23F", "#E63946", "#330000"]
                                    }}
                                    transition={{ duration: 12, ease: "easeInOut", times: [0, 0.1, 0.8, 1] }}
                                    className="absolute z-50 pointer-events-none"
                                >
                                    <Feather className="w-5 h-5 drop-shadow-[0_0_10px_currentColor]" style={{ color: 'currentColor' }} />
                                </motion.div>
                            )}
                        </AnimatePresence>

                        {/* Sacrifice Ash */}
                        {ashParticles.map(p => (
                             <motion.div
                                key={p.id}
                                initial={{ opacity: 1, y: -40 }}
                                animate={{ opacity: 0, y: 60, x: p.x - 50 }}
                                transition={{ duration: 3 }}
                                className="absolute w-1 h-1 bg-zinc-500 rounded-full z-30"
                             />
                        ))}
                    </div>
                    <div className={`text-current font-orbitron text-[10px] tracking-[0.3em] animate-pulse relative z-10 mt-2 ${isListening ? 'text-cyan-400 font-bold' : ''}`}>
                        {isListening ? 'LISTENING // AUDIO_GATE_OPEN' : 'PHOENIX // LIVE FEED'}
                    </div>
                </div>

                <div className="p-6 space-y-6">
                    {/* 2. CORE TEMP */}
                    <div className="flex justify-between items-center group">
                        <div className="flex items-center gap-2 text-zinc-500 text-sm font-bold uppercase tracking-wider group-hover:text-current transition-colors">
                            <Thermometer className="w-4 h-4" /> Core Temp
                        </div>
                        <div className={`text-sm font-mono font-bold flex items-baseline gap-1 ${telemetry.thermal > 80 ? 'text-[#E63946] animate-pulse' : 'text-white'}`}>
                            {telemetry.thermal.toFixed(1)}
                            <span className="text-xs text-zinc-600 font-normal">°C</span>
                        </div>
                    </div>

                    {/* 3. STORAGE */}
                    <div className="flex justify-between items-center group border-b border-zinc-900 pb-6">
                        <div className="flex items-center gap-2 text-zinc-500 text-sm font-bold uppercase tracking-wider group-hover:text-current transition-colors">
                            <HardDrive className="w-4 h-4" /> Storage (ENC)
                        </div>
                        <div className="text-sm font-mono font-bold text-white flex items-center gap-2">
                            <Lock className="w-3 h-3 text-[#F77F00]" />
                            4.2 <span className="text-xs text-zinc-600 font-sans font-normal">PB</span>
                        </div>
                    </div>

                    {/* 4. UPTIME */}
                    <div className="bg-black border border-zinc-900 p-4 rounded-lg relative overflow-hidden group">
                        <div className="absolute top-0 left-0 h-[1px] bg-gradient-to-r from-current to-transparent w-full animate-[shimmer_2s_infinite]" style={{ color: secondaryColor }}></div>
                        <div className="flex items-center justify-between relative z-10">
                            <div className="flex items-center gap-2 text-zinc-500 text-sm font-bold uppercase">
                                <Clock className="w-4 h-4 text-current" style={{ color: secondaryColor }} /> Uptime
                            </div>
                            <div className="text-sm font-mono font-bold" style={{ color: secondaryColor }}>
                                {uptime}
                            </div>
                        </div>
                    </div>

                    {/* 5. RESOURCE VECTOR */}
                    <div className="relative h-52 w-full my-4">
                        <div className="absolute top-0 left-0 text-[10px] text-zinc-500 font-bold uppercase flex items-center gap-2">
                            <Activity className="w-3 h-3" /> Resource Vector
                        </div>
                        <ResponsiveContainer width="100%" height="100%">
                            <RadarChart cx="50%" cy="55%" outerRadius="70%" data={data}>
                                <PolarGrid stroke="#27272a" />
                                <PolarAngleAxis dataKey="subject" tick={{ fill: '#52525b', fontSize: 9, fontWeight: 'bold' }} />
                                <Radar name="System" dataKey="A" stroke={primaryColor} strokeWidth={2} fill={primaryColor} fillOpacity={0.1} />
                            </RadarChart>
                        </ResponsiveContainer>
                    </div>

                    {/* 6. COMPUTE LOAD */}
                    <div className="space-y-2">
                         <div className="flex justify-between items-end text-zinc-500 font-bold uppercase tracking-wider">
                            <span className="flex items-center gap-2 text-sm"><Zap className="w-4 h-4 text-current" style={{ color: secondaryColor }} /> Compute Load</span>
                            <span className="text-sm font-mono font-bold" style={{ color: secondaryColor }}>{telemetry.cpu.toFixed(0)} %</span>
                        </div>
                        <div className="h-14 w-full bg-zinc-900/20 rounded border border-zinc-900 relative overflow-hidden">
                             <ResponsiveContainer width="100%" height="100%">
                                <LineChart data={loadHistory}>
                                    <Line type="monotone" dataKey="value" stroke={secondaryColor} strokeWidth={2} dot={false} isAnimationActive={false} />
                                    <YAxis domain={[0, 100]} hide />
                                </LineChart>
                            </ResponsiveContainer>
                        </div>
                    </div>

                    {/* 7. NEURAL CONTEXT */}
                    <div className="space-y-3">
                        <div className="flex justify-between items-end text-zinc-500 font-bold uppercase tracking-wider">
                            <span className="flex items-center gap-2 text-sm"><Database className="w-4 h-4" /> Neural Context</span>
                            <div className="flex items-center gap-2">
                                {onClearContext && (
                                    <button onClick={onClearContext} className="text-zinc-600 hover:text-[#b91c1c] transition-colors p-1" title="Incinerate Context">
                                        <Trash2 className="w-3 h-3" />
                                    </button>
                                )}
                                <span className="text-sm font-mono font-bold text-white">17 %</span>
                            </div>
                        </div>
                        <div className="w-full bg-zinc-900 h-2 rounded-full overflow-hidden relative">
                            <div className="h-full bg-[#b91c1c]" style={{ width: '17%' }}></div>
                        </div>
                    </div>
                </div>
            </div>
            
            {/* 9. EMERGENCY OVERRIDE & PROTECT (FIXED BOTTOM) */}
            <div className="p-4 pt-2 mt-auto bg-[#050505] border-t border-zinc-900/50 shrink-0 relative z-20">
                <div className="flex gap-2">
                        {/* PROTECT BUTTON */}
                        <button
                        onClick={onProtectToggle}
                        className={`flex-1 relative h-12 border transition-all overflow-hidden rounded group select-none flex items-center justify-center gap-2 font-bold font-orbitron text-xs tracking-[0.1em] uppercase ${
                            isProtected 
                            ? 'bg-[#1a1a05] border-[#FFD23F] text-[#FFD23F] shadow-[0_0_15px_rgba(255,210,63,0.2)]' 
                            : 'bg-[#050505] border-zinc-800 text-zinc-500 hover:border-[#FFD23F]/50 hover:text-white'
                        }`}
                        >
                        {isProtected ? <ShieldCheck className="w-4 h-4 animate-pulse" /> : <Shield className="w-4 h-4" />}
                        <span>{isProtected ? 'PROTECTED' : 'PROTECT'}</span>
                        </button>

                        {/* KILL BUTTON */}
                        <button
                        onMouseDown={startOverride}
                        onMouseUp={endOverride}
                        onMouseLeave={endOverride}
                        onTouchStart={startOverride}
                        onTouchEnd={endOverride}
                        disabled={screenCracked}
                        className={`flex-1 relative h-12 bg-[#1a0505] border transition-all overflow-hidden rounded group select-none ${screenCracked ? 'opacity-50 cursor-not-allowed' : `border-current/30 hover:border-current text-current`}`}
                        style={{ color: primaryColor }}
                        >
                        <div className="absolute top-0 left-0 h-full transition-all duration-75 ease-linear opacity-20" style={{ width: `${overrideProgress}%`, backgroundColor: primaryColor }} />
                        <div className="relative z-10 flex items-center justify-center gap-3 font-bold font-orbitron text-xs tracking-[0.2em] uppercase h-full">
                            <Skull className={`w-4 h-4 ${holdingOverride ? 'animate-pulse' : ''}`} />
                            <span>{holdingOverride ? 'KILL' : 'KILL'}</span>
                        </div>
                        </button>
                </div>
            </div>
        </div>
    );
};

export default DigitalTwin;
