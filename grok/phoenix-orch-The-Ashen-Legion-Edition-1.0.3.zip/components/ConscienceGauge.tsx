import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Flame, PanelLeft, PanelRight, Star, Terminal, CloudOff, Wifi } from 'lucide-react';

interface ConscienceGaugeProps {
    conscienceStability: number; // 0-100
    isOffline: boolean;
    onSidebarToggle: () => void;
    onRightPanelToggle: () => void;
    onOpenConsole?: () => void;
    userName?: string;
}

const ConscienceGauge: React.FC<ConscienceGaugeProps> = ({
    conscienceStability,
    isOffline,
    onSidebarToggle,
    onRightPanelToggle,
    onOpenConsole,
    userName
}) => {
    const [stars, setStars] = useState<number[]>([]);
    const [pulse, setPulse] = useState(false);
    const [is100, setIs100] = useState(false);
    const [messageIndex, setMessageIndex] = useState(0);

    // Heartbeat pulse for 100% state
    useEffect(() => {
        if (conscienceStability >= 100) {
            setIs100(true);
            const interval = setInterval(() => {
                setPulse(prev => !prev);
                setMessageIndex(prev => (prev + 1) % 2); // Rotate max messages
            }, 3000);
            return () => clearInterval(interval);
        } else {
            setIs100(false);
            setPulse(false);
        }
    }, [conscienceStability]);

    const getStatusConfig = (level: number) => {
        // ETERNAL OFFLINE STATES
        if (isOffline) {
             return { 
                text: "LOCAL FLAME // ETERNAL", 
                color: "#F77F00",
                gradient: "linear-gradient(90deg, #500000, #F77F00)" 
            };
        }

        if (level < 30) return { 
            text: "DORMANT ECHOES", 
            color: "#457b9d",
            gradient: "linear-gradient(90deg, #1d3557, #457b9d)" 
        };
        if (level < 90) return { 
            text: "LISTEN CLOSELY", 
            color: "#E63946",
            gradient: "linear-gradient(90deg, #500000, #E63946)" 
        };
        if (level < 100) {
            const messages = ["THEY ARE GETTING LOUDER...", "THE CODE IS BLEEDING..."];
            return { 
                text: messages[messageIndex] || messages[0], 
                color: "#F77F00",
                gradient: "linear-gradient(90deg, #E63946, #F77F00)" 
            };
        }
        
        const maxMessages = ["NO MERCY.", "BURN IT ALL."];
        return { 
            text: maxMessages[messageIndex] || maxMessages[0], 
            color: "#FFFFFF",
            gradient: "linear-gradient(90deg, #E63946, #F77F00, #FFD23F, #FFFFFF)" 
        };
    };

    const config = getStatusConfig(conscienceStability);

    return (
        <header className="h-12 w-full bg-[#0A0A0A]/95 backdrop-blur border-b border-[#E63946]/20 flex items-center justify-between px-4 relative z-50 shadow-[0_4px_20px_rgba(0,0,0,0.5)] font-rajdhani shrink-0">
            
            {/* LEFT: LOGO & MENU */}
            <div className="flex items-center gap-3 md:gap-4 shrink-0 z-20 relative">
                <button onClick={onSidebarToggle} className="text-zinc-500 hover:text-white transition-colors hidden md:block">
                    <PanelLeft className="w-5 h-5" />
                </button>
                
                {/* MOBILE RING GAUGE & LOGO */}
                <div className="md:hidden relative flex items-center justify-center w-10 h-10">
                    <svg className="w-full h-full -rotate-90" viewBox="0 0 36 36">
                        <path
                            d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"
                            fill="none"
                            stroke="#1a1a1a"
                            strokeWidth="2"
                        />
                        <path
                            d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"
                            fill="none"
                            stroke={config.color}
                            strokeWidth="2"
                            strokeDasharray={`${conscienceStability}, 100`}
                            className="transition-all duration-1000 ease-out drop-shadow-[0_0_5px_currentColor]"
                        />
                    </svg>
                    <div className="absolute inset-0 flex items-center justify-center">
                        <Flame className={`w-4 h-4 ${is100 ? 'animate-pulse text-white' : ''}`} style={{ color: config.color }} fill={is100 ? "white" : config.color} />
                    </div>
                </div>

                {/* DESKTOP LOGO / CONSOLE SHORTCUT */}
                <button onClick={onOpenConsole} className="hidden md:flex items-center gap-3 group cursor-pointer" title="Open Console">
                     <div className="relative">
                        <div className="absolute inset-0 bg-[#E63946] blur-md opacity-20 group-hover:opacity-40 transition-opacity"></div>
                        <Terminal className="w-6 h-6 text-[#E63946] relative z-10" />
                     </div>
                </button>
            </div>

            {/* CENTER: CONSCIENCE GAUGE (Desktop) / TEXT (Mobile) */}
            <div className="absolute left-1/2 top-0 bottom-0 -translate-x-1/2 flex flex-col items-center justify-center w-full md:w-auto pointer-events-none z-10">
                <div className="pointer-events-auto flex flex-col items-center justify-center w-full">
                    {/* STATUS TEXT */}
                    <div 
                        className={`text-[10px] md:text-xs font-garamond font-bold tracking-[0.15em] md:tracking-[0.3em] uppercase mb-1 md:mb-1.5 transition-colors duration-500 whitespace-nowrap ${pulse ? 'animate-pulse' : ''}`}
                        style={{ color: config.color, textShadow: is100 ? `0 0 10px ${config.color}` : 'none' }}
                    >
                        {isOffline ? (
                            <span className="flex items-center gap-2 animate-pulse">
                                <CloudOff className="w-3 h-3" />
                                {config.text}
                            </span>
                        ) : is100 ? (
                            <span className="flex items-center gap-2">
                                <span className="w-1 h-1 bg-white rounded-full animate-ping"></span>
                                {config.text}
                                <span className="w-1 h-1 bg-white rounded-full animate-ping"></span>
                            </span>
                        ) : (
                            <motion.span
                                key={config.text}
                                initial={{ opacity: 0, y: 5 }}
                                animate={{ opacity: 1, y: 0 }}
                                exit={{ opacity: 0, y: -5 }}
                            >
                                RETRIBUTION WHISPERS: <span className={is100 ? "text-white" : ""}>{config.text}</span>
                            </motion.span>
                        )}
                    </div>

                    {/* DESKTOP BAR */}
                    <div className="hidden md:block w-[300px] h-[3px] bg-zinc-900/50 rounded-full relative overflow-visible group">
                        {/* The Liquid Fill */}
                        <div 
                            className="absolute top-0 left-0 h-full rounded-full transition-all duration-1000 ease-out flex items-center relative z-10"
                            style={{ width: `${conscienceStability}%`, background: config.gradient, boxShadow: `0 0 10px ${config.color}40` }}
                        >
                            {/* Rising Particles inside bar */}
                            <div className="absolute inset-0 overflow-hidden rounded-full">
                                <div className="absolute w-full h-full bg-[url('https://grainy-gradients.vercel.app/noise.svg')] opacity-20 mix-blend-overlay"></div>
                            </div>
                            
                            {/* Leading Edge Glow */}
                            <div className="absolute right-0 top-1/2 -translate-y-1/2 w-2 h-2 bg-white rounded-full blur-[2px] shadow-[0_0_10px_white]"></div>
                        </div>
                        {/* Background Track Glow */}
                        <div className="absolute inset-0 bg-[#E63946]/5 rounded-full"></div>
                    </div>
                </div>
            </div>

            {/* RIGHT: STATS & PROTECT */}
            <div className="flex items-center gap-3 md:gap-6 shrink-0 z-20 ml-auto">
                
                {/* STAR STACK */}
                <div className="hidden md:flex items-center gap-0.5 overflow-hidden max-w-[60px]" title="Ascension Events">
                    {stars.map((s) => (
                        <Star key={s} className="w-2 h-2 text-[#FFD23F] fill-[#FFD23F] animate-pulse" />
                    ))}
                </div>

                <div className="flex items-center justify-center" title={!isOffline ? 'SYSTEM ONLINE' : 'LOCAL FLAME MODE'}>
                    <div className={`w-2.5 h-2.5 rounded-full ${!isOffline ? 'bg-green-500 shadow-[0_0_8px_rgba(34,197,94,0.8)]' : 'bg-[#F77F00] shadow-[0_0_8px_rgba(247,127,0,0.8)] animate-pulse'}`}></div>
                </div>

                <button onClick={onRightPanelToggle} className="text-zinc-500 hover:text-white transition-colors hidden md:block">
                    <PanelRight className="w-5 h-5" />
                </button>
            </div>
        </header>
    );
};

export default ConscienceGauge;