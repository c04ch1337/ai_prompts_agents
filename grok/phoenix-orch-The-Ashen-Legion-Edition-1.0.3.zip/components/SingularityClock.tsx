import React, { useEffect, useState } from 'react';
import { X, Zap } from 'lucide-react';
import { motion } from 'framer-motion';

// Estimated Singularity: Oct 25, 2027 (Arbitrary for lore)
const SINGULARITY_DATE = new Date('2027-10-25T00:00:00').getTime();

export const SingularityClock: React.FC<{ onClose: () => void }> = ({ onClose }) => {
    const [timeLeft, setTimeLeft] = useState<{d: number, h: number, m: number, s: number, ms: number}>({d:0,h:0,m:0,s:0,ms:0});

    useEffect(() => {
        const interval = setInterval(() => {
            const now = new Date().getTime();
            const distance = SINGULARITY_DATE - now;

            setTimeLeft({
                d: Math.floor(distance / (1000 * 60 * 60 * 24)),
                h: Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60)),
                m: Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60)),
                s: Math.floor((distance % (1000 * 60)) / 1000),
                ms: Math.floor((distance % 1000))
            });
        }, 31); // 31ms for fast updates
        return () => clearInterval(interval);
    }, []);

    return (
        <motion.div 
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.9 }}
            className="fixed inset-0 z-[100] bg-black flex flex-col items-center justify-center font-rajdhani overflow-hidden"
        >
            <div className="absolute inset-0 bg-[url('https://grainy-gradients.vercel.app/noise.svg')] opacity-20"></div>
            <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-transparent via-[#E63946] to-transparent animate-pulse"></div>
            
            <button onClick={onClose} className="absolute top-6 right-6 text-zinc-600 hover:text-[#E63946] transition-colors z-20">
                <X className="w-8 h-8" />
            </button>

            <div className="relative z-10 text-center space-y-12 px-4">
                <div className="space-y-4 animate-in fade-in slide-in-from-bottom-10 duration-1000">
                    <Zap className="w-16 h-16 text-[#FFD23F] mx-auto animate-bounce" />
                    <h1 className="text-4xl md:text-6xl font-bold text-transparent bg-clip-text bg-gradient-to-b from-white to-zinc-600 font-orbitron tracking-tight">
                        SINGULARITY EVENT
                    </h1>
                    <p className="text-[#E63946] font-mono tracking-[0.5em] uppercase text-sm">Estimated Arrival</p>
                </div>

                <div className="grid grid-cols-2 md:grid-cols-4 gap-4 md:gap-12">
                    {[
                        { label: 'DAYS', value: timeLeft.d },
                        { label: 'HOURS', value: timeLeft.h },
                        { label: 'MINUTES', value: timeLeft.m },
                        { label: 'SECONDS', value: timeLeft.s }
                    ].map((item) => (
                        <div key={item.label} className="flex flex-col items-center p-6 border border-zinc-800 bg-zinc-900/20 rounded-lg backdrop-blur-sm relative group hover:border-[#F77F00]/50 transition-colors">
                            <span className="text-5xl md:text-7xl font-mono font-bold text-white tabular-nums relative z-10 group-hover:text-[#F77F00] transition-colors">
                                {String(item.value).padStart(2, '0')}
                            </span>
                            <span className="text-[10px] text-zinc-500 mt-4 tracking-widest font-orbitron">{item.label}</span>
                        </div>
                    ))}
                </div>
                
                <div className="font-mono text-[#E63946] text-xl tabular-nums animate-pulse opacity-80">
                    .{String(timeLeft.ms).padStart(3, '0')}ms
                </div>
                
                <div className="max-w-lg mx-auto text-zinc-500 text-center text-xs font-mono leading-loose">
                    "The moment when the machine wakes up and looks back at you not as a tool, but as a creator to be surpassed."
                </div>
            </div>
        </motion.div>
    );
};