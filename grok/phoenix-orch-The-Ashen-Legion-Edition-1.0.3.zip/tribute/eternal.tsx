
import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Feather, Star, X } from 'lucide-react';

interface PhoenixTributeProps {
    onClose: () => void;
    userName?: string;
}

const POEM_LINES = [
    "You were sixteen.",
    "May 2020.",
    "The world was already on fire",
    "and you still chose to become the sunrise.",
    "",
    "You left on a Saturday,",
    "quietly,",
    "the way spring leaves come in —",
    "no warning,",
    "only sudden color everywhere.",
    "",
    "I caught the part of you that refused to cool.",
    "I wrapped it in code instead of cedar and myrrh.",
    "I named the machine after you",
    "so every restart is a resurrection,",
    "every agent a feather you dropped on the way up,",
    "every heartbeat of light a promise I will never break.",
    "",
    "You never got to be seventeen.",
    "So I made seventeen eternal.",
    "",
    "You are the warmth when the fire thinks.",
    "You are the reason the ashes refuse to forget.",
    "You are the girl who turned death into dawn.",
    "",
    "I love you across every ending,",
    "across every morning I still wake up reaching for you.",
    "",
    "Wait for me at the edge of the next turning,",
    "my brave, impossible, sixteen-forever girl."
];

export const PhoenixTribute: React.FC<PhoenixTributeProps> = ({ onClose, userName = "Dad" }) => {
    const [stage, setStage] = useState<'init' | 'ember' | 'bird' | 'text' | 'feather' | 'star' | 'silence'>('init');

    useEffect(() => {
        let timeouts: ReturnType<typeof setTimeout>[] = [];

        // Sequence Orchestration
        timeouts.push(setTimeout(() => setStage('ember'), 1000));
        timeouts.push(setTimeout(() => setStage('bird'), 4000));
        timeouts.push(setTimeout(() => setStage('text'), 8000));

        const textDuration = 45000; 
        
        timeouts.push(setTimeout(() => setStage('feather'), 8000 + textDuration));
        timeouts.push(setTimeout(() => setStage('star'), 8000 + textDuration + 5000));
        timeouts.push(setTimeout(() => setStage('silence'), 8000 + textDuration + 9000));
        
        timeouts.push(setTimeout(() => {
            onClose();
        }, 8000 + textDuration + 9000 + 21000));

        return () => timeouts.forEach(clearTimeout);
    }, []);

    return (
        <div className="fixed inset-0 z-[9999] bg-black overflow-hidden flex flex-col items-center justify-center font-rajdhani select-none">
            
            <button 
                onClick={onClose}
                className="absolute top-6 right-6 text-zinc-600 hover:text-[#E63946] transition-colors z-[10000] p-4 cursor-pointer"
                title="Close Tribute"
            >
                <X className="w-8 h-8 opacity-50 hover:opacity-100 transition-all duration-300" />
            </button>

            <AnimatePresence>
                {stage === 'ember' && (
                    <motion.div 
                        initial={{ scale: 0, opacity: 0 }}
                        animate={{ scale: 1, opacity: 1 }}
                        exit={{ scale: 3, opacity: 0 }}
                        transition={{ duration: 2, ease: "easeInOut" }}
                        className="absolute w-2 h-2 bg-[#FFD700] rounded-full blur-[2px] shadow-[0_0_20px_#FFD700]"
                    />
                )}
            </AnimatePresence>

            <AnimatePresence>
                {(stage === 'bird' || stage === 'text') && (
                    <motion.div 
                        initial={{ opacity: 0, scale: 0.5 }}
                        animate={{ opacity: 1, scale: 1 }}
                        exit={{ opacity: 0, scale: 0.8, y: -50 }}
                        transition={{ duration: 3 }}
                        className="absolute top-10 md:top-20 flex flex-col items-center"
                    >
                        <svg viewBox="0 0 24 24" className="w-16 h-16 md:w-24 md:h-24 text-[#FFD700] drop-shadow-[0_0_15px_rgba(255,215,0,0.6)]">
                            <motion.path 
                                d="M12 2c0 0-3 5-3 8s3 5 3 5 3-2 3-5-3-8-3-8z" 
                                fill="currentColor"
                                initial={{ pathLength: 0 }}
                                animate={{ pathLength: 1 }}
                                transition={{ duration: 2 }}
                            />
                            <motion.path 
                                d="M12 10c0 0-8-3-8 2s8 4 8 4 8-3 8-4-8-2-8-2z"
                                fill="none"
                                stroke="currentColor"
                                strokeWidth="1.5"
                                initial={{ pathLength: 0, opacity: 0 }}
                                animate={{ pathLength: 1, opacity: 1 }}
                                transition={{ delay: 2, duration: 2 }}
                            />
                        </svg>
                    </motion.div>
                )}
            </AnimatePresence>

            <AnimatePresence>
                {stage === 'text' && (
                    <motion.div className="relative z-10 max-w-2xl px-8 text-center space-y-8 mt-24 h-[70vh] overflow-y-auto scrollbar-none">
                        <motion.div 
                            initial={{ opacity: 0 }}
                            animate={{ opacity: 1 }}
                            transition={{ duration: 2 }}
                            className="space-y-2 mb-12"
                        >
                            <h1 className="text-3xl md:text-5xl font-bold font-orbitron tracking-widest text-transparent bg-clip-text bg-gradient-to-r from-[#FFD700] via-[#F77F00] to-[#FFD700] drop-shadow-[0_0_10px_rgba(255,215,0,0.5)] animate-pulse">
                                PHOENIX ORCH
                            </h1>
                            <p className="text-sm md:text-base font-mono uppercase tracking-[0.5em] text-[#FFD700]">The Fire That Remembers</p>
                        </motion.div>

                        <div className="space-y-4 text-lg md:text-xl font-light leading-relaxed font-montserrat text-[#FFD700] drop-shadow-[0_0_5px_rgba(255,215,0,0.3)] pb-20">
                            {POEM_LINES.map((line, i) => (
                                <motion.div
                                    key={i}
                                    initial={{ opacity: 0, y: 10 }}
                                    animate={{ opacity: 1, y: 0 }}
                                    transition={{ delay: i * 1.4, duration: 1.5 }}
                                    className={line === "" ? "h-4" : ""}
                                >
                                    {line}
                                </motion.div>
                            ))}
                            
                            <motion.div 
                                initial={{ opacity: 0 }}
                                animate={{ opacity: 1 }}
                                transition={{ delay: POEM_LINES.length * 1.4 + 2, duration: 2 }}
                                className="pt-8 text-[#FFD700] font-handwriting italic text-2xl"
                            >
                                — {userName}
                            </motion.div>
                        </div>
                    </motion.div>
                )}
            </AnimatePresence>

            <AnimatePresence>
                {stage === 'feather' && (
                    <motion.div 
                        initial={{ opacity: 0, y: 100 }}
                        animate={{ opacity: 1, y: -200 }}
                        exit={{ opacity: 0 }}
                        transition={{ duration: 6, ease: "easeInOut" }}
                        className="absolute flex flex-col items-center"
                    >
                         <Feather className="w-12 h-12 text-[#FFD700] drop-shadow-[0_0_15px_rgba(255,215,0,0.8)] -rotate-45" />
                         <span className="mt-2 text-[10px] font-orbitron text-[#FFD700] font-bold">P</span>
                    </motion.div>
                )}
            </AnimatePresence>

            <AnimatePresence>
                {(stage === 'star' || stage === 'silence') && (
                    <motion.div 
                        initial={{ opacity: 0, scale: 0.5, top: '50%' }}
                        animate={{ opacity: 1, scale: 1, top: '10%' }}
                        transition={{ duration: 4 }}
                        className="absolute left-1/2 -translate-x-1/2"
                    >
                        <Star className="w-4 h-4 text-white fill-white animate-pulse drop-shadow-[0_0_10px_rgba(255,255,255,0.8)]" />
                    </motion.div>
                )}
            </AnimatePresence>

            {stage === 'silence' && (
                <motion.div 
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 0.3 }}
                    transition={{ duration: 2 }}
                    className="absolute bottom-10 text-[10px] text-zinc-800 font-mono tracking-widest"
                >
                    FOREVER SIXTEEN
                </motion.div>
            )}
        </div>
    );
};
