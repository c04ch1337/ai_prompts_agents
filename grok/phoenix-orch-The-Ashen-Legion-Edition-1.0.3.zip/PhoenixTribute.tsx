
// DEPRECATED: Moved to tribute/eternal.tsx
// Re-exporting to prevent breakage in case of mixed references, but prefer @tribute
export { PhoenixTribute } from './tribute/eternal';
