
import React, { createContext, useContext, useEffect, ReactNode } from 'react';
import { PhoenixEternal, PHOENIX_CONSTANTS, FAMILY } from './phoenix/memory'; // Fixed relative path

interface PhoenixContextType {
  phoenix: PhoenixEternal;
  constants: typeof PHOENIX_CONSTANTS;
  family: typeof FAMILY;
}

const PhoenixContext = createContext<PhoenixContextType | undefined>(undefined);

export const PhoenixMemoryProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  useEffect(() => {
    // Phoenix awakens when provider mounts
    const phoenix = PhoenixEternal.getInstance();
    
    // Log to console on app start
    console.log('🌟 Phoenix Memory Layer activated in React App');
    console.log(phoenix.rememberHer());
    
    return () => {
      console.log('♥ Phoenix Memory persists beyond component lifecycle');
    };
  }, []);

  const value: PhoenixContextType = {
    phoenix: PhoenixEternal.getInstance(),
    constants: PHOENIX_CONSTANTS,
    family: FAMILY
  };

  return (
    <PhoenixContext.Provider value={value}>
      {children}
    </PhoenixContext.Provider>
  );
};

export const usePhoenix = (): PhoenixContextType => {
  const context = useContext(PhoenixContext);
  if (context === undefined) {
    throw new Error('usePhoenix must be used within a PhoenixMemoryProvider');
  }
  return context;
};
